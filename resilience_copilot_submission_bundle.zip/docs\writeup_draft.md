# Resilience Copilot: Safety-First Disaster Relief Triage with Gemma 4

Resilience Copilot is a disaster-relief triage assistant for messy evacuation cases where a family may need shelter, medication continuity, transport, pet accommodation, and responder handoff at the same time.

The core problem is not only answering quickly. During floods, heatwaves, and evacuations, a generic chatbot can sound confident while missing risk signals or inventing real-time shelter capacity. That is dangerous. Our design goal is to make Gemma 4 useful while keeping operational safety boundaries visible.

The prototype takes a short case note and returns five sections:

1. Risk level.
2. Case signals.
3. Action plan.
4. Clarifying questions.
5. Safety boundary.

For example, when a family of five is evacuated after a flood, two children are cold, a grandmother forgot blood pressure medication, and the family needs a pet-compatible shelter, the system marks the case high risk. It surfaces child cold exposure, medication interruption, and pet shelter constraints, then creates a responder handoff plan.

The original contribution is a lightweight safety sidecar. Before generation, it detects high-risk signals such as children, older adults, medication interruption, electrical hazards, floodwater, dialysis continuity, and transport barriers. Those signals are passed into the response layer as explicit constraints: do not diagnose, do not invent local shelter capacity, and escalate immediate danger to official responders.

Gemma 4 evidence was captured in Kaggle Notebook using the official model resource:

`/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`

The notebook logs Python 3.12.12, Torch 2.10.0+cu128, Transformers 5.8.0.dev0, CUDA on Tesla T4, prompt, response, latency, and generated token count. One recorded run produced 160 new tokens with 18.014 seconds latency.

Local validation uses scenario split rather than a training/test CSV split because this hackathon has no provided dataset. Demo cases are used for product presentation. Holdout cases are reserved for safety checks and are not baked into prompts. Current local validation passes 2/2 demo cases and 2/2 holdout cases.

The intended users are community volunteers, shelter coordinators, and small emergency-response teams who need structured triage notes rather than polished but unsafe advice. The assistant does not replace emergency services. It reduces friction by converting incomplete case notes into safer next actions and clearer questions for human responders.

Next steps are connecting official local shelter feeds, adding responder-approved playbooks, and deploying the demo publicly with the same safety boundaries.
