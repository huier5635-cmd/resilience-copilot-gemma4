# The Gemma 4 Good Hackathon

Kaggle project workspace for a prize-oriented Gemma 4 Good submission. This is a hackathon, not a normal tabular competition: there is no provided training dataset and the deliverable is a Kaggle Writeup plus public demo assets.

## Competition Reading

- Competition: https://www.kaggle.com/competitions/gemma-4-good-hackathon
- Data: `data/raw/NOTE.md` says no dataset is provided.
- Submission: one Kaggle Writeup per team.
- Required assets: Kaggle Writeup, public code repository, public live demo, public video, media/gallery cover.
- Evaluation focus: impact and vision, video pitch/storytelling, technical depth/execution.
- Deadline recorded from competition page: 2026-05-18 23:59 UTC, which is 2026-05-19 07:59 in China.

## Current Product Track

Working title: **Resilience Copilot**.

Goal: a safety-first crisis-relief assistant for floods, evacuation, medication access, shelter triage, pet-compatible shelter routing, and responder handoff. The first baseline is deliberately narrow so we can prove the loop quickly, then add Gemma 4 evidence and small original improvements.

Current status: submitted to Kaggle on 2026-05-13, refreshed on 2026-05-14, and refreshed again on 2026-05-15 for EXP-023. The latest submitted Kaggle version adds auditable playbook grounding, a copy-ready responder packet, a safe household-facing holding message, a machine-readable audit trace, a Kaggle-ready final writeup check, a judge-facing evidence matrix, a decision brief, copy-ready packet button, heatwave/cooling-center official routing, and an updated `resilience_copilot_submission_bundle_EXP023.zip` attachment. It passes the expanded 11-case stress gate and the submitted Kaggle page documents the 12-section response and 11/11 stress validation. EXP-024 added structured case export. EXP-026 added explicit `Human review reason`. EXP-028 is the current local candidate: it adds a `Source verification ledger` for stale social-media claims, live-capacity rumors, route/facility freshness, and official-channel evidence; local stress validation now passes 14/14. EXP-028 should be synced before a Kaggle refresh.

Submitted writeup:

`https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`

## Public Links

- Public demo: https://huier5635-cmd.github.io/resilience-copilot-gemma4/
- Public code: https://github.com/huier5635-cmd/resilience-copilot-gemma4
- YouTube video: https://youtu.be/CmqCV8Ic9cY
- Kaggle Gemma 4 evidence notebook: https://www.kaggle.com/code/zhenhuier/notebook5022dfd167

## Directory Map

- `docs/`: local project notes plus selected judge-facing writeup and evidence documents. Internal working notes stay local and are not part of the GitHub display surface.
- `notebooks/public_reproduction/`: downloaded public Kaggle notebooks and review notes.
- `notebooks/experiments/`: our own Kaggle/local evidence notebooks.
- `scripts/`: local validation, baseline, evidence, and asset checks.
- `outputs/local_validation/`: generated reports and validation artifacts.

## Storage Policy

Gemma-related project files, browser profile data, downloads, evidence bundles, and Ollama model files should stay under `D:\Kaggle\Gemma4Good`.

- Project workspace: `D:\Kaggle\Gemma4Good\New project 5`
- Gemma Chrome profile: `D:\Kaggle\Gemma4Good\ChromeDebugProfile_Gemma`
- Gemma downloads: `D:\Kaggle\Gemma4Good\Downloads`
- Gemma temp/check files: `D:\Kaggle\Gemma4Good\Temp`
- Ollama data: `D:\Kaggle\Gemma4Good\Ollama\.ollama`
- User environment variable: `OLLAMA_MODELS=D:\Kaggle\Gemma4Good\Ollama\.ollama\models`

Do not intentionally download new Gemma/Kaggle assets to the C drive. For temporary verification downloads, use `D:\Kaggle\Gemma4Good\Temp` instead of `%TEMP%`. The legacy paths `C:\ChromeDebugProfile_Gemma` and `C:\Users\Liaoke\.ollama` are junctions into D, so old commands can keep working without storing large data on C.

## Local Validation

Run the full local gate:

```powershell
python scripts\run_local_validation.py
```

Run only the demo-case evaluation:

```powershell
python scripts\evaluate_demo_cases.py --cases data\cases\demo_cases.jsonl --output outputs\local_validation\demo_eval.json
```

Current final gate:

- `ready_to_submit=true`
- demo cases: 2/2
- holdout cases: 2/2
- stress cases: 14/14 locally; the latest submitted EXP-023 Kaggle writeup documents 11/11
- writeup readiness: checked locally against word count, links, and evidence terms
- judging packet: checked locally against rubric map, links, assets, and validation results
- public evidence surface: GitHub Pages verified on 2026-05-15 with `Responder packet`, `Household message`, and `Audit trace`
- Kaggle checklist: 7/7
- final Kaggle submission: created

## Local Demo

The current project demo runs on port 7861 because port 7860 is already occupied by another local process:

```powershell
$env:PORT='7861'
python app\app.py
```

Open `http://127.0.0.1:7861`.

Durable public static demo:

`https://huier5635-cmd.github.io/resilience-copilot-gemma4/`

Use the GitHub Pages link as the public demo in the Kaggle writeup. Stale quick-tunnel links should stay out of the judge-facing Kaggle page.

## Assets

- Video draft: `outputs/submission_assets/resilience_copilot_caption_video_20260513.webm`
- Pitch deck: `outputs/submission_assets/resilience_copilot_pitch_v2.pptx`
- Static deployment package: `outputs/submission_assets/public_demo_static.zip`
- Submission bundle: `outputs/submission_assets/resilience_copilot_submission_bundle.zip`
- Evidence report: `outputs/local_validation/evidence_report.md`

Root-level public repo assets:

- `resilience_copilot_pitch_v2.pptx`
- `resilience_copilot_submission_bundle.zip`

Refresh the submission bundle after changing project assets:

```powershell
python scripts\build_submission_bundle.py
```

EXP-022 public repo refresh: GitHub Pages and the public source/demo were refreshed on 2026-05-15. This did not consume a Kaggle final submission slot because the Kaggle writeup URL and public demo URL stayed unchanged.

EXP-023 Kaggle refresh: the demo now shows a compact decision brief, supports `Copy packet`, and includes heatwave/cooling-center routing through public health and official emergency-management channels. Kaggle was refreshed on 2026-05-15 with the EXP-023 writeup and `resilience_copilot_submission_bundle_EXP023.zip`.

EXP-024 local/public demo candidate: the demo now includes `Copy JSON` and a structured case export with `case_fingerprint`, `review_level`, `required_human_review`, `blocked_claims`, and `response_contract`. This has not consumed another Kaggle submission slot yet.

EXP-026 local candidate: the demo now includes `Human Review Reason` and the structured export includes `human_review_reason`. This raises the local stress gate to 13/13 and is a low-risk original enhancement for the next Kaggle refresh after public demo sync.

EXP-028 local candidate: the demo now includes `Source Verification Ledger` and the structured export includes `source_verification`. This raises the local stress gate to 14/14 and is the next literature-backed original enhancement for the final Kaggle refresh.

## Submission Policy

- No direct Kaggle submission until `scripts\run_local_validation.py` reports the required assets and evidence are ready. The 2026-05-13 submission followed this rule.
- Public reproduction is capped at two online attempts per day.
- At least one original or micro-tuning branch must remain prepared for every submission round.
- Every experiment must record hypothesis, command, local result, online result if any, rank if applicable, and next action.
