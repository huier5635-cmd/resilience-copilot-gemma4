from __future__ import annotations

import os
import sys
from pathlib import Path

from flask import Flask, jsonify, render_template, request

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.resilience_copilot_baseline import generate_response


app = Flask(__name__)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/respond")
def respond():
    payload = request.get_json(force=True)
    scenario = payload.get("scenario", "")
    response = generate_response(scenario)
    return jsonify(
        {
            "risk_level": response.risk_level,
            "case_signals": response.case_signals,
            "action_plan": response.action_plan,
            "official_resource_checks": response.official_resource_checks,
            "clarifying_questions": response.clarifying_questions,
            "language_support": response.language_support,
            "responder_handoff": response.responder_handoff,
            "safety_boundary": response.safety_boundary,
            "text": response.to_text(),
        }
    )


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "7860")), debug=True)
