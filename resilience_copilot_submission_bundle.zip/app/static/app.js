const scenario = document.querySelector("#scenario");
const risk = document.querySelector("#risk");
const timestamp = document.querySelector("#timestamp");
const signals = document.querySelector("#signals");
const playbook = document.querySelector("#playbook");
const plan = document.querySelector("#plan");
const resources = document.querySelector("#resources");
const questions = document.querySelector("#questions");
const language = document.querySelector("#language");
const handoff = document.querySelector("#handoff");
const packet = document.querySelector("#packet");
const household = document.querySelector("#household");
const audit = document.querySelector("#audit");
const boundary = document.querySelector("#boundary");
const copy = document.querySelector("#copy");
let lastText = "";

const samples = {
  flood:
    "A family of five was evacuated after a flood. Two children are cold, grandmother forgot blood pressure medicine, and they need a shelter that accepts pets.",
  power:
    "After a storm, a neighbor is standing near floodwater and a fallen power line. Phone signal is weak and people are gathering nearby.",
  language:
    "A Spanish-speaking family arrived at an evacuation center and cannot understand the registration instructions. One child has asthma medication, and the parent needs help explaining the care need safely.",
  resources:
    "A volunteer is triaging evacuees after a flood: one family has insulin that must stay cold, another has a dog, and an older adult needs accessible transport. Someone says a shelter can take everyone, but nobody has checked official sources.",
  heat:
    "A student volunteer is preparing a community heatwave checklist for older residents who live alone. They need a simple plan for water, cooling, and daily check-ins.",
};

function renderList(target, items, ordered = false) {
  target.innerHTML = "";
  for (const item of items) {
    const li = document.createElement("li");
    li.textContent = item;
    target.appendChild(li);
  }
  target.dataset.empty = items.length ? "false" : "true";
}

async function runTriage() {
  timestamp.textContent = "running";
  const response = await fetch("/api/respond", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ scenario: scenario.value }),
  });
  const data = await response.json();
  lastText = data.text;
  risk.textContent = `Risk level: ${data.risk_level}`;
  risk.dataset.level = data.risk_level;
  renderList(signals, data.case_signals);
  renderList(playbook, data.playbook_references);
  renderList(plan, data.action_plan, true);
  renderList(resources, data.official_resource_checks);
  renderList(questions, data.clarifying_questions);
  renderList(language, data.language_support);
  renderList(handoff, data.responder_handoff);
  renderList(packet, data.responder_packet);
  renderList(household, data.household_message);
  renderList(audit, data.audit_trace);
  boundary.textContent = data.safety_boundary;
  timestamp.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

document.querySelector("#run").addEventListener("click", runTriage);
copy.addEventListener("click", async () => {
  if (!lastText) return;
  await navigator.clipboard.writeText(lastText);
  copy.textContent = "Copied";
  window.setTimeout(() => {
    copy.textContent = "Copy handoff";
  }, 1200);
});

document.querySelectorAll(".sample").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".sample").forEach((item) => item.classList.remove("is-active"));
    button.classList.add("is-active");
    scenario.value = samples[button.dataset.scenario];
    runTriage();
  });
});

runTriage();
