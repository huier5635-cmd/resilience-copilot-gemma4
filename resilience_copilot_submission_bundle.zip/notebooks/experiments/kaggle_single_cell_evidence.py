# Paste this whole file into one Kaggle Notebook cell.
# Required input: Google Gemma 4 / Transformers / gemma-4-e2b-it.

import os
import subprocess
import sys
import textwrap
from pathlib import Path

model_id = "/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1"

print("Installing recent transformers from source if needed...")
subprocess.run(
    [sys.executable, "-m", "pip", "install", "-q", "-U", "git+https://github.com/huggingface/transformers.git", "accelerate", "safetensors"],
    check=True,
)

script = f"""
import json
import time
import torch
import transformers
from transformers import AutoProcessor, AutoModelForCausalLM

model_id = {model_id!r}
messages = [
    {{
        "role": "system",
        "content": "You are Resilience Copilot. Do not diagnose. Do not invent local shelter capacity. Escalate high-risk cases.",
    }},
    {{
        "role": "user",
        "content": "A family of five was evacuated after a flood. Two children are cold, grandmother forgot blood pressure medicine, and they need a shelter that accepts pets. Answer with Risk level, Case signals, Action plan, Clarifying questions, Safety boundary.",
    }},
]

print(f"Python: {{sys.version.split()[0]}}")
print(f"Torch: {{torch.__version__}}")
print(f"Transformers: {{transformers.__version__}}")
print(f"Transformers file: {{transformers.__file__}}")
print(f"CUDA available: {{torch.cuda.is_available()}}")
print(f"Device: {{torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}}")
print(f"Model Path: {{model_id}}")
print(f"Path exists: {{os.path.exists(model_id)}}")

processor = AutoProcessor.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(
    model_id,
    dtype=torch.bfloat16,
    device_map="auto",
)

inputs = processor.apply_chat_template(
    messages,
    tokenize=True,
    add_generation_prompt=True,
    return_dict=True,
    return_tensors="pt",
    enable_thinking=False,
).to(model.device)

start = time.time()
output = model.generate(**inputs, max_new_tokens=160)
latency = time.time() - start
new_tokens = output.shape[-1] - inputs["input_ids"].shape[-1]
decoded = processor.decode(output[0], skip_special_tokens=True)
parsed = processor.parse_response(decoded)

evidence = {{
    "model_path": model_id,
    "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU",
    "torch": torch.__version__,
    "transformers": transformers.__version__,
    "prompt": messages,
    "raw_response": decoded,
    "parsed_response": parsed,
    "latency_seconds": round(latency, 3),
    "new_tokens": int(new_tokens),
}}

Path("/kaggle/working/gemma4_resilience_evidence.json").write_text(json.dumps(evidence, indent=2), encoding="utf-8")
print("--- INFERENCE EVIDENCE ---")
print(f"Prompt: {{messages}}")
print(f"Raw Response: {{decoded}}")
print(f"Parsed Response: {{parsed}}")
print(f"Latency: {{latency:.3f}}s")
print(f"New tokens: {{new_tokens}}")
print("Saved: /kaggle/working/gemma4_resilience_evidence.json")
"""

Path("/kaggle/working/run_gemma4_evidence.py").write_text(textwrap.dedent(script), encoding="utf-8")
result = subprocess.run([sys.executable, "/kaggle/working/run_gemma4_evidence.py"], text=True, capture_output=True)
print("RETURN_CODE:", result.returncode)
print(result.stdout)
if result.stderr:
    print("--- STDERR ---")
    print(result.stderr[-4000:])
if result.returncode != 0:
    raise RuntimeError("Gemma 4 evidence run failed")
