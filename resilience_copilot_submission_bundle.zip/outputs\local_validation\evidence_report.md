# Local Evidence Report

## Gate

- Ready to submit: `True`
- Demo cases: 2 / 2
- Holdout cases: 2 / 2

## Gemma 4 Runtime

- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`
- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`
- Status: ready.

## Local Demo

- Screenshot: `outputs\local_validation\local_demo_upgraded_7861_20260513.png`
- Static package: `outputs\submission_assets\public_demo_static.zip`
- Public code repo: `https://github.com/huier5635-cmd/resilience-copilot-gemma4`
- Public live demo: `https://huier5635-cmd.github.io/resilience-copilot-gemma4/`

## Kaggle Draft

- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`
- Checklist: 7/7 complete.
- Submission status: submitted.
- Final submission created: `True`
- Screenshot: `outputs\local_validation\kaggle_writeup_submitted_verified_20260513.png`

## Video

- Local draft: `outputs\submission_assets\resilience_copilot_caption_video_20260513.webm`
- Public YouTube URL: `https://youtu.be/CmqCV8Ic9cY`

## Missing Assets

