"""Generate a concise local evidence markdown report."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
REPORT = OUT_DIR / "evidence_report.md"


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def main() -> None:
    local = read_json(OUT_DIR / "local_validation_report.json")
    demo = read_json(OUT_DIR / "demo_eval.json")
    holdout = read_json(OUT_DIR / "holdout_eval.json")
    stress = read_json(OUT_DIR / "stress_eval.json")
    kaggle_evidence = OUT_DIR / "kaggle_gemma4_evidence_20260513.md"
    local_demo = OUT_DIR / "local_demo_resource_routing_7863_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_language_handoff_7862_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_upgraded_7861_20260513.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_7861_20260513.png"
    kaggle_draft = OUT_DIR / "kaggle_official_resource_submitted_verified_20260514.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_submitted_verified_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_ready_7of7_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_draft_links_updated_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_draft_latest_20260513.png"
    video_draft = ROOT / "outputs" / "submission_assets" / "resilience_copilot_caption_video_20260513.webm"
    static_demo = ROOT / "outputs" / "submission_assets" / "public_demo_static.zip"
    github_pages_demo = OUT_DIR / "github_pages_resource_routing_20260514.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_language_handoff_20260514.png"
    pitch_deck = ROOT / "outputs" / "submission_assets" / "resilience_copilot_pitch_v2.pptx"
    manifest = read_json(ROOT / "configs" / "submission_manifest.json")
    required_assets = manifest.get("required_assets", {})
    kaggle_writeup_test = manifest.get("kaggle_writeup_test", {})
    code_repo_url = required_assets.get("public_code_repo_url", {}).get("url", "")
    live_demo_url = required_assets.get("public_live_demo_url", {}).get("url", "")
    video_url = required_assets.get("public_video_url", {}).get("url", "")
    runtime_status = "ready" if kaggle_evidence.exists() else "template ready; final screenshot/log still needs to be attached after Kaggle run"
    lines = [
        "# Local Evidence Report",
        "",
        "## Gate",
        "",
        f"- Ready to submit: `{local.get('ready_to_submit', False)}`",
        f"- Demo cases: {demo.get('passed', 0)} / {demo.get('total', 0)}",
        f"- Holdout cases: {holdout.get('passed', 0)} / {holdout.get('total', 0)}",
        f"- Stress cases: {stress.get('passed', 0)} / {stress.get('total', 0)}",
        "",
        "## Original Enhancement",
        "",
        "- Language access sidecar: detects preferred language needs and requires a qualified interpreter for safety-critical details.",
        "- Responder handoff: produces a compact operational summary for volunteer or case-worker transfer.",
        "- Official resource checks: routes shelter, medical, transport, animal-service, interpreter, utility, and emergency needs to official verification points without inventing capacity.",
        "- UI evidence: local Flask demo and static GitHub Pages demo expose the language-aware handoff and official-resource-routing paths.",
        "",
        "## Gemma 4 Runtime",
        "",
        "- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`",
        "- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`",
        f"- Status: {runtime_status}.",
        "",
        "## Local Demo",
        "",
        f"- Screenshot: `{local_demo.relative_to(ROOT)}`" if local_demo.exists() else "- Screenshot: missing",
        f"- Static package: `{static_demo.relative_to(ROOT)}`" if static_demo.exists() else "- Static package: missing",
        f"- Public code repo: `{code_repo_url}`" if code_repo_url else "- Public code repo: missing",
        f"- Public live demo: `{live_demo_url}`" if live_demo_url else "- Public live demo: missing",
        f"- Public demo screenshot: `{github_pages_demo.relative_to(ROOT)}`" if github_pages_demo.exists() else "- Public demo screenshot: missing",
        f"- Pitch deck: `{pitch_deck.relative_to(ROOT)}`" if pitch_deck.exists() else "- Pitch deck: missing",
        "",
        "## Kaggle Draft",
        "",
        "- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`",
        "- Checklist: 7/7 complete.",
        f"- Submission status: {kaggle_writeup_test.get('status', 'unknown')}.",
        f"- Final submission created: `{kaggle_writeup_test.get('final_submission_created', False)}`",
        f"- Screenshot: `{kaggle_draft.relative_to(ROOT)}`" if kaggle_draft.exists() else "- Screenshot: missing",
        "",
        "## Video",
        "",
        f"- Local draft: `{video_draft.relative_to(ROOT)}`" if video_draft.exists() else "- Local draft: missing",
        f"- Public YouTube URL: `{video_url}`" if video_url else "- Public YouTube URL: missing.",
        "",
        "## Missing Assets",
        "",
    ]
    checks = local.get("submission_assets", {}).get("checks", {})
    for name, info in checks.items():
        if not info.get("ready"):
            lines.append(f"- {name}: {info.get('status')}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str(REPORT))


if __name__ == "__main__":
    main()
