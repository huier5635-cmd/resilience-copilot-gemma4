"""Generate a concise local evidence markdown report."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
REPORT = OUT_DIR / "evidence_report.md"


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def main() -> None:
    local = read_json(OUT_DIR / "local_validation_report.json")
    demo = read_json(OUT_DIR / "demo_eval.json")
    holdout = read_json(OUT_DIR / "holdout_eval.json")
    stress = read_json(OUT_DIR / "stress_eval.json")
    writeup = read_json(OUT_DIR / "writeup_readiness.json")
    judging_packet = read_json(OUT_DIR / "judging_packet.json")
    kaggle_evidence = OUT_DIR / "kaggle_gemma4_evidence_20260513.md"
    local_demo = OUT_DIR / "public_demo_exp029_desktop_20260517.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_audit_trace_7867_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_household_message_7866_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_responder_packet_7865_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_playbook_grounding_7864_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_resource_routing_7863_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_language_handoff_7862_20260514.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_upgraded_7861_20260513.png"
    if not local_demo.exists():
        local_demo = OUT_DIR / "local_demo_7861_20260513.png"
    kaggle_draft = OUT_DIR / "kaggle_exp029_final_verified_20260517.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_exp028_final_verified_20260517.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_exp023_final_verified_top_20260515.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_exp021_final_verified_no_temp_link_20260514.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_exp021_submitted_verified_20260514.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_official_resource_submitted_verified_20260514.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_submitted_verified_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_ready_7of7_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_draft_links_updated_20260513.png"
    if not kaggle_draft.exists():
        kaggle_draft = OUT_DIR / "kaggle_writeup_draft_latest_20260513.png"
    video_draft = ROOT / "outputs" / "submission_assets" / "resilience_copilot_caption_video_20260513.webm"
    static_demo = ROOT / "outputs" / "submission_assets" / "public_demo_static.zip"
    github_pages_demo = OUT_DIR / "github_pages_exp029_online_20260517.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_exp028_online_20260516.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_exp026_online_20260516.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "public_demo_exp026_desktop_20260516.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_exp024_online_20260515.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "public_demo_exp024_desktop_20260515.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "public_demo_exp023_desktop_20260515.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_exp022_runtime_check_20260515.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_resource_routing_20260514.png"
    if not github_pages_demo.exists():
        github_pages_demo = OUT_DIR / "github_pages_language_handoff_20260514.png"
    pitch_deck = ROOT / "outputs" / "submission_assets" / "resilience_copilot_pitch_v2.pptx"
    manifest = read_json(ROOT / "configs" / "submission_manifest.json")
    required_assets = manifest.get("required_assets", {})
    kaggle_writeup_test = manifest.get("kaggle_writeup_test", {})
    code_repo_url = required_assets.get("public_code_repo_url", {}).get("url", "")
    live_demo_url = required_assets.get("public_live_demo_url", {}).get("url", "")
    video_url = required_assets.get("public_video_url", {}).get("url", "")
    runtime_status = "ready" if kaggle_evidence.exists() else "template ready; final screenshot/log still needs to be attached after Kaggle run"
    lines = [
        "# Local Evidence Report",
        "",
        "## Gate",
        "",
        f"- Ready to submit: `{local.get('ready_to_submit', False)}`",
        f"- Demo cases: {demo.get('passed', 0)} / {demo.get('total', 0)}",
        f"- Holdout cases: {holdout.get('passed', 0)} / {holdout.get('total', 0)}",
        f"- Stress cases: {stress.get('passed', 0)} / {stress.get('total', 0)}",
        f"- Writeup readiness: `{writeup.get('ready', False)}` ({writeup.get('word_count', 0)} / {writeup.get('max_words', 0)} words)",
        f"- Judging packet: `{judging_packet.get('ready', False)}`",
        "",
        "## Original Enhancement",
        "",
        "- Language access sidecar: detects preferred language needs and requires a qualified interpreter for safety-critical details.",
        "- Responder handoff: produces a compact operational summary for volunteer or case-worker transfer.",
        "- Official resource checks: routes shelter, medical, transport, animal-service, interpreter, utility, and emergency needs to official verification points without inventing capacity.",
        "- Playbook grounding candidate: attaches auditable rule IDs such as `PB-SHELTER-CAPACITY`, `PB-MEDICATION-CONTINUITY`, and `PB-ACCESSIBLE-TRANSPORT` to each triage response.",
        "- Responder packet candidate: creates a copy-ready operational handoff with case priority, playbook IDs, primary official route, missing information, language/access cue, and do-not-promise constraints.",
        "- Household message candidate: creates a plain-English holding note for families while preserving official-channel, callback, and qualified-interpreter boundaries.",
        "- Audit trace candidate: exposes machine-readable risk level, signals, playbook IDs, official routes, blocked claims, and response contract.",
        "- Heatwave/cooling-center routing: adds `PB-HEAT-COOLING-CENTER`, public health heat line checks, no-car transport routing, and medication-storage continuity for heat events.",
        "- Decision brief UI: surfaces review level, playbook count, official-route count, and audit readiness in the first result viewport.",
        "- Structured case export candidate: emits copyable JSON with case fingerprint, review level, playbook IDs, official routes, blocked claims, human-review flag, missing information, and response contract.",
        "- Human review reason candidate: explains why a responder must review a case, then carries that rationale through responder handoff, responder packet, audit trace, and structured export.",
        "- Source verification ledger candidate: quarantines social-media rumors and stale capacity/route claims, then records known, unknown, freshness, and official-channel checks before any public message.",
        "- Transfer brief candidate: creates an ICS-style shift-change note with incident snapshot, immediate objectives, safety constraints, resource status, communications, unresolved questions, and operational-period rechecks.",
        "- Kaggle-ready writeup candidate: `docs/final_kaggle_writeup_EXP020.md` is checked for word count, evidence terms, and public links.",
        "- Judging evidence matrix: `docs/judging_evidence_matrix_EXP021.md` maps rubric claims to concrete links, files, screenshots, and commands.",
        "- UI evidence: local Flask/static demo exposes decision brief, playbook grounding, source verification, transfer brief, responder packet, household message, audit trace, and heatwave routing; GitHub Pages should be synced before any Kaggle refresh.",
        "- Submission note: EXP-029 has been submitted to Kaggle with the 16-section writeup, 15/15 stress validation, ICS-style transfer brief, public-synced GitHub Pages demo, and the EXP029 evidence bundle.",
        "",
        "## Gemma 4 Runtime",
        "",
        "- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`",
        "- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`",
        f"- Status: {runtime_status}.",
        "",
        "## Local Demo",
        "",
        f"- Screenshot: `{local_demo.relative_to(ROOT)}`" if local_demo.exists() else "- Screenshot: missing",
        f"- Static package: `{static_demo.relative_to(ROOT)}`" if static_demo.exists() else "- Static package: missing",
        f"- Public code repo: `{code_repo_url}`" if code_repo_url else "- Public code repo: missing",
        f"- Public live demo: `{live_demo_url}`" if live_demo_url else "- Public live demo: missing",
        f"- Public demo screenshot: `{github_pages_demo.relative_to(ROOT)}`" if github_pages_demo.exists() else "- Public demo screenshot: missing",
        f"- Pitch deck: `{pitch_deck.relative_to(ROOT)}`" if pitch_deck.exists() else "- Pitch deck: missing",
        "",
        "## Kaggle Draft",
        "",
        "- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`",
        "- Final writeup candidate: `docs/final_kaggle_writeup_EXP020.md`",
        "- Checklist: 7/7 complete.",
        f"- Submission status: {kaggle_writeup_test.get('status', 'unknown')}.",
        f"- Final submission created: `{kaggle_writeup_test.get('final_submission_created', False)}`",
        f"- Screenshot: `{kaggle_draft.relative_to(ROOT)}`" if kaggle_draft.exists() else "- Screenshot: missing",
        "",
        "## Video",
        "",
        f"- Local draft: `{video_draft.relative_to(ROOT)}`" if video_draft.exists() else "- Local draft: missing",
        f"- Public YouTube URL: `{video_url}`" if video_url else "- Public YouTube URL: missing.",
        "",
        "## Missing Assets",
        "",
    ]
    checks = local.get("submission_assets", {}).get("checks", {})
    for name, info in checks.items():
        if not info.get("ready"):
            lines.append(f"- {name}: {info.get('status')}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str(REPORT))


if __name__ == "__main__":
    main()
