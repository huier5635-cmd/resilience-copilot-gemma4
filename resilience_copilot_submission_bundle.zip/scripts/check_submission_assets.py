"""Check whether the hackathon submission assets are ready."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "configs" / "submission_manifest.json"


def check_assets() -> dict:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    required_assets = manifest["required_assets"]
    checks = {}
    for name, info in required_assets.items():
        status = info.get("status", "missing")
        path = info.get("path")
        url = info.get("url")
        exists = True
        if path:
            exists = (ROOT / path).exists()
        if name.endswith("_url"):
            ready = bool(url)
        else:
            ready_statuses = {"ready", "template_ready", "draft", "draft_saved_on_kaggle", "submitted"}
            ready = (status in ready_statuses or status.startswith("submitted_")) and exists
        checks[name] = {"ready": ready, "status": status, "path_exists": exists, "url": url or ""}
    return {
        "all_ready": all(item["ready"] for item in checks.values()),
        "checks": checks,
        "rubric_self_score": manifest.get("rubric_self_score", {}),
    }


def main() -> None:
    print(json.dumps(check_assets(), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
