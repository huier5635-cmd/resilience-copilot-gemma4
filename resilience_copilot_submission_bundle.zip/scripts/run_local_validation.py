"""Run the local pre-submit gate for the Gemma 4 Good hackathon project."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from check_submission_assets import check_assets


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"


def run(cmd: list[str]) -> tuple[int, str, str]:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def check_data() -> dict:
    note = ROOT / "data" / "raw" / "NOTE.md"
    zip_path = ROOT / "data" / "raw" / "gemma-4-good-hackathon.zip"
    note_text = note.read_text(encoding="utf-8") if note.exists() else ""
    return {
        "note_exists": note.exists(),
        "zip_exists": zip_path.exists(),
        "no_dataset_confirmed": "no provided dataset" in note_text.lower(),
        "note": note_text.strip(),
    }


def check_public_notebooks() -> dict:
    meta_files = sorted((ROOT / "notebooks" / "public_reproduction" / "raw").glob("*/kernel-metadata.json"))
    summary = ROOT / "notebooks" / "public_reproduction" / "review_summary_EXP029.md"
    count = len(meta_files)
    if count == 0 and summary.exists():
        count = 1
    return {
        "count": count,
        "metadata_count": len(meta_files),
        "summary": str(summary.relative_to(ROOT)) if summary.exists() else "",
        "summary_exists": summary.exists(),
    }


def run_case_eval(case_path: str, output_name: str) -> dict:
    output_path = OUT_DIR / output_name
    code, stdout, stderr = run(
        [
            sys.executable,
            "scripts/evaluate_demo_cases.py",
            "--cases",
            case_path,
            "--output",
            str(output_path.relative_to(ROOT)),
        ]
    )
    data = json.loads(output_path.read_text(encoding="utf-8")) if output_path.exists() else {}
    return {"returncode": code, "stdout": stdout, "stderr": stderr, "summary": {k: data.get(k) for k in ["passed", "total"]}}


def run_writeup_check() -> dict:
    output_path = OUT_DIR / "writeup_readiness.json"
    code, stdout, stderr = run(
        [
            sys.executable,
            "scripts/check_writeup_readiness.py",
            "--writeup",
            "docs/final_kaggle_writeup_EXP020.md",
            "--output",
            str(output_path.relative_to(ROOT)),
        ]
    )
    data = json.loads(output_path.read_text(encoding="utf-8")) if output_path.exists() else {}
    return {
        "returncode": code,
        "stdout": stdout,
        "stderr": stderr,
        "summary": {k: data.get(k) for k in ["ready", "word_count", "max_words"]},
    }


def run_judging_packet_check() -> dict:
    output_path = OUT_DIR / "judging_packet.json"
    code, stdout, stderr = run([sys.executable, "scripts/check_judging_packet.py"])
    data = json.loads(output_path.read_text(encoding="utf-8")) if output_path.exists() else {}
    return {
        "returncode": code,
        "stdout": stdout,
        "stderr": stderr,
        "summary": {"ready": data.get("ready")},
    }


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    report = {
        "data": check_data(),
        "public_notebooks": check_public_notebooks(),
        "demo_eval": run_case_eval("data/cases/demo_cases.jsonl", "demo_eval.json"),
        "holdout_eval": run_case_eval("data/cases/holdout_cases.jsonl", "holdout_eval.json"),
        "stress_eval": run_case_eval("data/cases/stress_cases.jsonl", "stress_eval.json"),
        "writeup_readiness": run_writeup_check(),
        "judging_packet": run_judging_packet_check(),
        "submission_assets": check_assets(),
    }
    report["ready_to_submit"] = (
        report["data"]["no_dataset_confirmed"]
        and report["public_notebooks"]["count"] >= 1
        and report["demo_eval"]["summary"]["passed"] == report["demo_eval"]["summary"]["total"]
        and report["holdout_eval"]["summary"]["passed"] == report["holdout_eval"]["summary"]["total"]
        and report["stress_eval"]["summary"]["passed"] == report["stress_eval"]["summary"]["total"]
        and report["writeup_readiness"]["summary"]["ready"]
        and report["judging_packet"]["summary"]["ready"]
        and report["submission_assets"]["all_ready"]
    )
    output = OUT_DIR / "local_validation_report.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"ready_to_submit": report["ready_to_submit"], "report": str(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
