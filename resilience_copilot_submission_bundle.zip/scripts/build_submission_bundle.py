"""Build a compact submission evidence bundle for the Gemma 4 Good project."""

from __future__ import annotations

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "submission_assets" / "resilience_copilot_submission_bundle.zip"


INCLUDE_FILES = [
    "README.md",
    "requirements.txt",
    "configs/submission_manifest.json",
    "docs/final_kaggle_writeup_EXP020.md",
    "docs/judging_evidence_matrix_EXP021.md",
    "data/cases/demo_cases.jsonl",
    "data/cases/holdout_cases.jsonl",
    "data/cases/stress_cases.jsonl",
    "data/raw/NOTE.md",
    "outputs/local_validation/evidence_report.md",
    "outputs/local_validation/local_validation_report.json",
    "outputs/local_validation/kaggle_exp021_final_verification.json",
    "outputs/local_validation/writeup_readiness.json",
    "outputs/local_validation/judging_packet.json",
    "outputs/local_validation/demo_eval.json",
    "outputs/local_validation/holdout_eval.json",
    "outputs/local_validation/stress_eval.json",
    "outputs/local_validation/kaggle_gemma4_evidence_20260513.md",
    "outputs/local_validation/local_demo_resource_routing_7863_20260514.png",
    "outputs/local_validation/public_demo_resource_routing_20260514.png",
    "outputs/local_validation/local_demo_playbook_grounding_7864_20260514.png",
    "outputs/local_validation/public_demo_playbook_grounding_20260514.png",
    "outputs/local_validation/local_demo_responder_packet_7865_20260514.png",
    "outputs/local_validation/public_demo_responder_packet_20260514.png",
    "outputs/local_validation/public_demo_responder_packet_crop_20260514.png",
    "outputs/local_validation/local_demo_household_message_7866_20260514.png",
    "outputs/local_validation/public_demo_household_message_20260514.png",
    "outputs/local_validation/public_demo_household_message_crop_20260514.png",
    "outputs/local_validation/public_demo_household_message_vietnamese_crop_20260514.png",
    "outputs/local_validation/local_demo_audit_trace_7867_20260514.png",
    "outputs/local_validation/public_demo_audit_trace_crop_20260514.png",
    "outputs/local_validation/kaggle_exp021_submitted_verified_20260514.png",
    "outputs/local_validation/kaggle_exp021_final_verified_no_temp_link_20260514.png",
    "outputs/local_validation/github_pages_exp022_runtime_check_20260515.json",
    "outputs/local_validation/github_pages_exp022_runtime_check_20260515.png",
    "outputs/local_validation/public_demo_exp023_runtime_check_20260515.json",
    "outputs/local_validation/public_demo_exp023_desktop_20260515.png",
    "outputs/local_validation/public_demo_exp023_mobile_20260515.png",
    "outputs/local_validation/github_pages_exp023_online_check_20260515.json",
    "outputs/local_validation/github_pages_exp023_online_20260515.png",
    "outputs/local_validation/github_pages_exp023_final_verification_20260515.json",
    "outputs/local_validation/kaggle_exp023_final_verification_20260515.json",
    "outputs/local_validation/kaggle_exp023_final_verified_top_20260515.png",
    "outputs/local_validation/kaggle_exp023_final_verified_files_20260515.png",
    "outputs/local_validation/public_demo_exp024_runtime_check_20260515.json",
    "outputs/local_validation/public_demo_exp024_desktop_20260515.png",
    "outputs/local_validation/public_demo_exp024_mobile_20260515.png",
    "outputs/local_validation/public_demo_exp026_runtime_check_20260516.json",
    "outputs/local_validation/public_demo_exp026_desktop_20260516.png",
    "outputs/local_validation/public_demo_exp026_mobile_20260516.png",
    "outputs/local_validation/github_pages_exp026_online_check_20260516.json",
    "outputs/local_validation/github_pages_exp026_online_20260516.png",
    "outputs/local_validation/github_pages_exp026_online_mobile_20260516.png",
    "outputs/local_validation/public_demo_exp028_runtime_check_20260516.json",
    "outputs/local_validation/public_demo_exp028_desktop_20260516.png",
    "outputs/local_validation/public_demo_exp028_mobile_20260516.png",
    "outputs/local_validation/github_pages_exp028_online_check_20260516.json",
    "outputs/local_validation/github_pages_exp028_online_20260516.png",
    "outputs/local_validation/github_pages_exp028_online_mobile_20260516.png",
    "outputs/local_validation/kaggle_exp028_final_verification_20260517.json",
    "outputs/local_validation/kaggle_exp028_final_verified_20260517.png",
    "outputs/local_validation/kaggle_exp028_final_verified_files_20260517.png",
    "outputs/local_validation/kaggle_exp029_final_verification_20260517.json",
    "outputs/local_validation/kaggle_exp029_final_verified_20260517.png",
    "outputs/local_validation/kaggle_exp029_final_verified_files_20260517.png",
    "outputs/local_validation/public_demo_exp029_desktop_20260517.png",
    "outputs/local_validation/public_demo_exp029_mobile_20260517.png",
    "outputs/local_validation/github_pages_exp029_online_check_20260517.json",
    "outputs/local_validation/github_pages_exp029_online_20260517.png",
    "outputs/local_validation/github_pages_exp029_online_mobile_20260517.png",
    "outputs/local_validation/stress_eval_exp029.json",
    "outputs/local_validation/github_pages_exp024_online_check_20260515.json",
    "outputs/local_validation/github_pages_exp024_online_20260515.png",
    "outputs/local_validation/github_pages_resource_routing_20260514.png",
    "outputs/local_validation/kaggle_official_resource_submitted_verified_20260514.png",
    "outputs/submission_assets/cover_resilience_copilot_560x280.png",
    "outputs/submission_assets/public_demo_static.zip",
    "outputs/submission_assets/resilience_copilot_pitch_v2.pptx",
]

INCLUDE_DIRS = [
    "app",
    "public_demo",
    "scripts",
    "knowledge_base",
    "notebooks/experiments",
]


def add_file(zip_file: ZipFile, relative_path: str) -> None:
    path = ROOT / relative_path
    if path.exists() and path.is_file():
        zip_file.write(path, relative_path)


def add_dir(zip_file: ZipFile, relative_dir: str) -> None:
    base = ROOT / relative_dir
    if not base.exists():
        return
    for path in sorted(base.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            zip_file.write(path, str(path.relative_to(ROOT)))


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUT, "w", compression=ZIP_DEFLATED) as zip_file:
        for relative_path in INCLUDE_FILES:
            add_file(zip_file, relative_path)
        for relative_dir in INCLUDE_DIRS:
            add_dir(zip_file, relative_dir)
    print(str(OUT))


if __name__ == "__main__":
    main()
