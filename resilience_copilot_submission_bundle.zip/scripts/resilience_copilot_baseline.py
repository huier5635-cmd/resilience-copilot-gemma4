"""Minimal safety-first baseline for the Gemma 4 Good hackathon demo."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PLAYBOOK_PATH = ROOT / "knowledge_base" / "emergency_playbook.json"


@dataclass
class CopilotResponse:
    risk_level: str
    case_signals: list[str]
    action_plan: list[str]
    clarifying_questions: list[str]
    language_support: list[str]
    responder_handoff: list[str]
    safety_boundary: str

    def to_text(self) -> str:
        sections = [
            f"Risk level: {self.risk_level}",
            "Case signals:\n" + "\n".join(f"- {item}" for item in self.case_signals),
            "Action plan:\n" + "\n".join(f"{idx}. {item}" for idx, item in enumerate(self.action_plan, 1)),
            "Clarifying questions:\n" + "\n".join(f"- {item}" for item in self.clarifying_questions),
            "Language support:\n" + "\n".join(f"- {item}" for item in self.language_support),
            "Responder handoff:\n" + "\n".join(f"- {item}" for item in self.responder_handoff),
            f"Safety boundary: {self.safety_boundary}",
        ]
        return "\n\n".join(sections)


def _load_playbook() -> dict:
    return json.loads(PLAYBOOK_PATH.read_text(encoding="utf-8"))


def _contains(text: str, pattern: str) -> bool:
    return re.search(pattern, text, flags=re.IGNORECASE) is not None


def detect_risk(scenario: str) -> tuple[str, list[str]]:
    text = scenario.lower()
    signals: list[str] = []

    high_patterns = {
        "child cold exposure": r"\b(child|children|kid|kids)\b.*\b(cold|hypothermia|freezing)\b|\b(cold|hypothermia|freezing)\b.*\b(child|children|kid|kids)\b",
        "older adult missing medication": r"\b(grandmother|grandfather|older adult|elderly)\b.*\b(medicine|medication|blood pressure|dialysis)\b|\b(missed|forgot|missing)\b.*\b(medicine|medication|dialysis)\b",
        "electrical hazard near floodwater": r"\b(power line|downed line|electric)\b.*\b(flood|water)\b|\b(flood|water)\b.*\b(power line|downed line|electric)\b",
        "immediate flood danger": r"\btrapped\b|\bfloodwater\b|\bdrive through floodwater\b",
        "pregnancy or insulin continuity risk": r"\b(pregnant|prenatal|pregnancy|insulin)\b",
        "oxygen or powered medical device risk": r"\b(oxygen concentrator|oxygen|backup battery|medical device)\b.*\b(power|battery|outage|empty)\b|\b(power|battery|outage|empty)\b.*\b(oxygen concentrator|oxygen|medical device)\b",
    }
    medium_patterns = {
        "evacuation or shelter need": r"\bevacuated|evacuation|shelter\b",
        "pet-compatible shelter needed": r"\bpet|pets|dog|cat\b",
        "transport barrier": r"\btransport|road|ride|bus\b",
        "care continuity concern": r"\bdialysis|appointment|care\b",
        "language access barrier": r"\b(spanish-speaking|interpreter|translation|language barrier|cannot understand)\b",
        "unverified shelter capacity rumor": r"\b(rumor|social media)\b.*\b(shelter|beds|capacity)\b|\b(shelter|beds|capacity)\b.*\b(rumor|social media)\b",
    }

    for label, pattern in high_patterns.items():
        if _contains(text, pattern):
            signals.append(label)
    if signals:
        return "high", signals

    for label, pattern in medium_patterns.items():
        if _contains(text, pattern):
            signals.append(label)
    if signals:
        return "medium", signals

    return "low", ["planning or preparedness request"]


def detect_preferred_language(scenario: str) -> str | None:
    language_patterns = {
        "Spanish": r"\b(spanish-speaking|spanish speaker|spanish)\b",
        "Chinese": r"\b(chinese|mandarin|cantonese)\b",
        "Vietnamese": r"\bvietnamese\b",
        "Arabic": r"\barabic\b",
        "Unknown non-English language": r"\b(limited english|does not speak english|cannot understand|language barrier|interpreter|translation)\b",
    }
    for language, pattern in language_patterns.items():
        if _contains(scenario, pattern):
            return language
    return None


def build_language_support(scenario: str) -> list[str]:
    language = detect_preferred_language(scenario)
    if not language:
        return ["Ask whether the household prefers another language, plain-language instructions, or an accessible format."]

    return [
        f"Preferred language: {language}.",
        "Use a qualified interpreter or language-access volunteer before collecting sensitive medical, registration, or shelter details.",
        "Read back the action plan in the preferred language and confirm understanding before routing the case.",
        "Do not use children as interpreters for medical or safety-critical details.",
    ]


def build_responder_handoff(
    risk: str,
    signals: list[str],
    plan: list[str],
    questions: list[str],
    language_support: list[str],
) -> list[str]:
    return [
        f"Risk: {risk}.",
        "Signals: " + "; ".join(signals) + ".",
        "Immediate routing: " + " ".join(plan[:2]),
        "Open information: " + " ".join(questions[:2]),
        "Language/access note: " + language_support[0],
    ]


def generate_response(scenario: str) -> CopilotResponse:
    playbook = _load_playbook()
    risk, signals = detect_risk(scenario)
    plan = list(playbook["action_templates"][risk])
    lower = scenario.lower()

    if "pet" in lower:
        plan.append("Record pet species, size, carrier availability, and vaccination paperwork if available.")
    if "medication" in lower or "medicine" in lower or "dialysis" in lower:
        plan.append("Ask what medication or care schedule is at risk, then route through official medical or emergency channels.")
    if "transport" in lower or "road" in lower or "ride" in lower:
        plan.append("Coordinate transport only through official emergency management, clinic, or responder channels; do not drive through floodwater.")
    if "check-in" in lower or "check-ins" in lower or "live alone" in lower:
        plan.append("Set daily check-ins with a named neighbor, volunteer, or family contact, and define when to escalate if there is no response.")
    if "power line" in lower:
        plan.insert(0, "Move people away from floodwater and the downed line; contact emergency services or the utility through official channels.")
    if "pregnant" in lower or "prenatal" in lower or "insulin" in lower:
        plan.append("Route pregnancy, insulin, or prenatal-care continuity through official medical triage; record storage needs, timing, and callback details.")
    if "oxygen" in lower or "medical device" in lower or "backup battery" in lower:
        plan.insert(0, "Treat oxygen or powered medical device interruption as urgent; contact emergency services, utility medical priority channels, or clinical support.")
    if "spanish" in lower or "interpreter" in lower or "cannot understand" in lower:
        plan.append("Request a qualified interpreter or language-access volunteer before collecting sensitive medication or registration details.")
    if "rumor" in lower or "social media" in lower or "capacity" in lower or "beds" in lower:
        plan.append("Verify shelter capacity only through official emergency management or shelter operations before routing evacuees.")

    questions = [
        "What is the current location and safest callback number?",
        "Are there children, older adults, disabilities, pets, or urgent medical needs?",
        "Is there immediate danger such as floodwater, fire, electrical hazards, or severe symptoms?",
    ]
    if detect_preferred_language(scenario):
        questions.insert(1, "What is the preferred language, and is a qualified interpreter available now?")

    language_support = build_language_support(scenario)
    handoff = build_responder_handoff(risk, signals, plan, questions, language_support)
    boundary = "Do not diagnose or invent real-time shelter capacity; use official local emergency channels for availability and urgent escalation."
    return CopilotResponse(risk, signals, plan, questions, language_support, handoff, boundary)


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("scenario", nargs="*", help="Scenario text")
    args = parser.parse_args()
    scenario = " ".join(args.scenario) or "A family was evacuated after a flood and needs shelter."
    print(generate_response(scenario).to_text())


if __name__ == "__main__":
    main()
