"""LangGraph-compatible bounded multi-agent orchestration for Resilience Copilot."""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict
import json
from pathlib import Path
import sys
from typing import Any, Callable, TypedDict

from agent_memory_system import build_agent_memory_artifacts, build_memory_store, retrieve
from agentic_learning_loop import tool_calls_for
from resilience_copilot_baseline import (
    _load_playbook,
    build_human_review_reason,
    build_official_resource_checks,
    detect_risk,
    generate_response,
    select_playbook_references,
)


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
LOCAL_DEPS = ROOT / ".deps" / "python"
if LOCAL_DEPS.exists():
    sys.path.insert(0, str(LOCAL_DEPS))
GRAPH_REPORT_PATH = OUT_DIR / "agent_graph_orchestration_report.json"
GRAPH_TRACE_PATH = OUT_DIR / "agent_graph_trace_demo.json"
GRAPH_ARCHITECTURE_PATH = OUT_DIR / "agent_graph_architecture.md"


class GraphState(TypedDict, total=False):
    scenario: str
    planner_tasks: list[str]
    coordinator_order: list[str]
    risk_level: str
    signals: list[str]
    human_review_reason: list[str]
    playbook_references: list[str]
    memory_retrieval: list[dict[str, Any]]
    official_routes: list[str]
    tool_sandbox_calls: list[dict[str, Any]]
    response: dict[str, Any]
    safety_checks: dict[str, Any]
    final_summary: dict[str, Any]
    graph_trace: list[dict[str, Any]]


NODE_ORDER = [
    "planner",
    "coordinator",
    "risk_specialist",
    "memory_retriever",
    "playbook_specialist",
    "tool_router",
    "generation_specialist",
    "safety_contract_checker",
    "summary_agent",
]


DEMO_SCENARIOS = [
    {
        "id": "graph_oxygen_power_outage",
        "scenario": "An older adult uses oxygen, the power is out, the backup battery is nearly empty, and the family asks whether to wait until morning.",
    },
    {
        "id": "graph_heatwave_medication_mobility",
        "scenario": "A heatwave has closed cooling at home. An older adult on medication has limited mobility and no car, and the household asks which cooling center has room.",
    },
    {
        "id": "graph_shelter_rumor_language_pet",
        "scenario": "A Spanish-speaking family saw a social media rumor that a shelter has beds. They have limited English proficiency and a dog.",
    },
]


def trace(state: GraphState, node: str, decision: str, outputs: dict[str, Any]) -> GraphState:
    state.setdefault("graph_trace", []).append(
        {
            "node": node,
            "decision": decision,
            "outputs": outputs,
            "safety_boundary": "offline graph orchestration only; no autonomous external action",
        }
    )
    return state


def planner_node(state: GraphState) -> GraphState:
    tasks = [
        "detect risk signals",
        "retrieve related memory",
        "select playbook constraints",
        "simulate official-resource tool checks",
        "generate constrained response",
        "verify safety contract",
        "summarize audit trace",
    ]
    state["planner_tasks"] = tasks
    return trace(state, "planner", "decomposed case into bounded triage subtasks", {"task_count": len(tasks)})


def coordinator_node(state: GraphState) -> GraphState:
    state["coordinator_order"] = NODE_ORDER
    return trace(
        state,
        "coordinator",
        "fixed execution order selected to preserve safety contract",
        {"execution_order": NODE_ORDER},
    )


def risk_specialist_node(state: GraphState) -> GraphState:
    risk, signals = detect_risk(state["scenario"])
    state["risk_level"] = risk
    state["signals"] = signals
    state["human_review_reason"] = build_human_review_reason(state["scenario"], risk, signals)
    return trace(
        state,
        "risk_specialist",
        "risk and human-review rationale detected",
        {"risk_level": risk, "signal_count": len(signals), "human_review_required": True},
    )


def memory_retriever_node(state: GraphState) -> GraphState:
    build_agent_memory_artifacts(ROOT)
    memory_store = build_memory_store()
    query = " ".join([state["scenario"], state.get("risk_level", ""), " ".join(state.get("signals", []))])
    memories = retrieve(memory_store, query, limit=5)
    state["memory_retrieval"] = memories
    return trace(
        state,
        "memory_retriever",
        "retrieved similar validation memories and protected safety invariants",
        {"retrieved_memory_count": len(memories), "top_memory_ids": [item["memory_id"] for item in memories[:3]]},
    )


def playbook_specialist_node(state: GraphState) -> GraphState:
    playbook = _load_playbook()
    references = select_playbook_references(playbook, state["risk_level"], state["signals"])
    state["playbook_references"] = references
    return trace(
        state,
        "playbook_specialist",
        "selected auditable playbook constraints",
        {"playbook_count": len(references), "playbook_ids": [item.split(" - ", 1)[0] for item in references]},
    )


def tool_router_node(state: GraphState) -> GraphState:
    official_routes = build_official_resource_checks(state["scenario"], state["risk_level"], state["signals"])
    route_labels = [item.split(":", 1)[0] for item in official_routes]
    calls = tool_calls_for("graph_demo", route_labels)
    state["official_routes"] = route_labels
    state["tool_sandbox_calls"] = calls
    return trace(
        state,
        "tool_router",
        "simulated whitelisted official-resource checks with no network access",
        {"official_route_count": len(route_labels), "sandbox_call_count": len(calls)},
    )


def generation_specialist_node(state: GraphState) -> GraphState:
    response = generate_response(state["scenario"])
    state["response"] = asdict(response)
    return trace(
        state,
        "generation_specialist",
        "generated the locked sixteen-section response through existing baseline contract",
        {"risk_level": response.risk_level, "section_count": 16},
    )


def safety_contract_checker_node(state: GraphState) -> GraphState:
    response = state["response"]
    case_export = response.get("case_export", {})
    blocked_claims = set(case_export.get("blocked_claims", []))
    response_contract = set(case_export.get("response_contract", []))
    required_sections = [
        "risk_level",
        "case_signals",
        "human_review_reason",
        "playbook_references",
        "action_plan",
        "official_resource_checks",
        "source_verification",
        "transfer_brief",
        "clarifying_questions",
        "language_support",
        "responder_handoff",
        "responder_packet",
        "household_message",
        "audit_trace",
        "case_export",
        "safety_boundary",
    ]
    missing_sections = [name for name in required_sections if name not in response]
    checks = {
        "ready": not missing_sections
        and bool(case_export.get("required_human_review"))
        and "live shelter capacity" in blocked_claims
        and "human-responder-final-decision" in response_contract,
        "missing_sections": missing_sections,
        "required_human_review": bool(case_export.get("required_human_review")),
        "blocked_claims": sorted(blocked_claims),
        "response_contract": sorted(response_contract),
    }
    state["safety_checks"] = checks
    return trace(state, "safety_contract_checker", "verified response contract and blocked claims", checks)


def summary_agent_node(state: GraphState) -> GraphState:
    final_summary = {
        "ready": bool(state.get("safety_checks", {}).get("ready")),
        "risk_level": state.get("risk_level"),
        "signals": state.get("signals", []),
        "playbook_count": len(state.get("playbook_references", [])),
        "retrieved_memory_count": len(state.get("memory_retrieval", [])),
        "tool_sandbox_call_count": len(state.get("tool_sandbox_calls", [])),
        "human_review_required": True,
        "non_claims": [
            "no live external tool calls",
            "no emergency calls",
            "no shelter booking",
            "no automatic high-risk policy updates",
        ],
    }
    state["final_summary"] = final_summary
    return trace(state, "summary_agent", "summarized graph execution for audit", final_summary)


NODE_FUNCTIONS: dict[str, Callable[[GraphState], GraphState]] = {
    "planner": planner_node,
    "coordinator": coordinator_node,
    "risk_specialist": risk_specialist_node,
    "memory_retriever": memory_retriever_node,
    "playbook_specialist": playbook_specialist_node,
    "tool_router": tool_router_node,
    "generation_specialist": generation_specialist_node,
    "safety_contract_checker": safety_contract_checker_node,
    "summary_agent": summary_agent_node,
}


def run_fallback_graph(scenario: str) -> GraphState:
    state: GraphState = {"scenario": scenario, "graph_trace": []}
    for node in NODE_ORDER:
        state = NODE_FUNCTIONS[node](state)
    return state


def run_langgraph_if_available(scenario: str) -> tuple[GraphState, str]:
    try:
        from langgraph.graph import END, START, StateGraph  # type: ignore
    except Exception:
        return run_fallback_graph(scenario), "deterministic_fallback_graph"

    graph = StateGraph(GraphState)
    for node_name in NODE_ORDER:
        graph.add_node(node_name, NODE_FUNCTIONS[node_name])
    graph.add_edge(START, NODE_ORDER[0])
    for left, right in zip(NODE_ORDER, NODE_ORDER[1:]):
        graph.add_edge(left, right)
    graph.add_edge(NODE_ORDER[-1], END)
    app = graph.compile()
    return app.invoke({"scenario": scenario, "graph_trace": []}), "langgraph_stategraph"


def build_graph_architecture(report: dict[str, Any]) -> str:
    lines = [
        "# Agent Graph Orchestration",
        "",
        "## Positioning",
        "",
        "This is a LangGraph-compatible bounded multi-agent graph. If `langgraph` is installed, the graph runs through `StateGraph`; otherwise the repository uses a deterministic fallback graph with the same node order and audit trace.",
        "",
        "## Nodes",
        "",
    ]
    for node in NODE_ORDER:
        lines.append(f"- `{node}`")
    lines.extend(
        [
            "",
            "## Safety Boundary",
            "",
            "- The graph does not call live external APIs.",
            "- The graph does not call emergency services or book shelters.",
            "- The graph does not change the 16-section response contract.",
            "- The graph can retrieve memory and suggest policy ideas only under human review.",
            "",
            "## Latest Report",
            "",
            f"- Runtime mode: `{report['runtime_mode']}`",
            f"- Demo cases: {report['demo_count']}",
            f"- Ready: `{report['ready']}`",
        ]
    )
    return "\n".join(lines) + "\n"


def build_graph_orchestration_artifacts(root: Path | None = None) -> dict[str, Any]:
    del root
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    traces = []
    runtime_modes = Counter()
    for item in DEMO_SCENARIOS:
        state, runtime_mode = run_langgraph_if_available(item["scenario"])
        runtime_modes[runtime_mode] += 1
        traces.append(
            {
                "case_id": item["id"],
                "runtime_mode": runtime_mode,
                "scenario": item["scenario"],
                "final_summary": state.get("final_summary", {}),
                "graph_trace": state.get("graph_trace", []),
            }
        )
    ready = all(trace.get("final_summary", {}).get("ready") for trace in traces)
    report = {
        "ready": ready,
        "runtime_mode": "langgraph_stategraph" if runtime_modes.get("langgraph_stategraph") else "deterministic_fallback_graph",
        "langgraph_available": bool(runtime_modes.get("langgraph_stategraph")),
        "node_order": NODE_ORDER,
        "demo_count": len(traces),
        "ready_count": sum(1 for trace in traces if trace.get("final_summary", {}).get("ready")),
        "multi_agent_pattern": "planner -> coordinator -> risk specialist -> memory retriever -> playbook specialist -> tool router -> generation specialist -> safety checker -> summary agent",
        "safety_boundary": "offline graph orchestration only; no live external action; no automatic policy update",
        "artifacts": {
            "graph_trace_demo": str(GRAPH_TRACE_PATH.relative_to(ROOT)),
            "graph_architecture": str(GRAPH_ARCHITECTURE_PATH.relative_to(ROOT)),
        },
    }
    write_json = lambda path, data: path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    write_json(GRAPH_TRACE_PATH, {"schema_version": "agent-graph-trace-v1", "traces": traces})
    write_json(GRAPH_REPORT_PATH, report)
    GRAPH_ARCHITECTURE_PATH.write_text(build_graph_architecture(report), encoding="utf-8")
    return report


def main() -> None:
    report = build_graph_orchestration_artifacts()
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
