"""Summarize downloaded public Kaggle notebooks for reproducibility review."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "notebooks" / "public_reproduction" / "raw"
OUT_PATH = ROOT / "outputs" / "local_validation" / "public_notebook_review.json"


def main() -> None:
    rows = []
    for metadata_path in sorted(RAW_DIR.glob("*/kernel-metadata.json")):
        meta = json.loads(metadata_path.read_text(encoding="utf-8"))
        rows.append(
            {
                "id": meta.get("id"),
                "title": meta.get("title"),
                "enable_gpu": meta.get("enable_gpu"),
                "enable_internet": meta.get("enable_internet"),
                "model_sources": meta.get("model_sources", []),
                "dataset_sources": meta.get("dataset_sources", []),
                "machine_shape": meta.get("machine_shape"),
                "local_path": str(metadata_path.parent.relative_to(ROOT)),
            }
        )
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps({"count": len(rows), "notebooks": rows}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"count": len(rows), "output": str(OUT_PATH)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
