"""Build a bounded long-term memory system from local validation feedback."""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date
import json
import math
import re
from pathlib import Path

from agentic_learning_loop import build_agentic_learning_artifacts


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
EXPERIENCE_LEDGER_PATH = OUT_DIR / "experience_ledger.jsonl"
FEEDBACK_MEMORY_PATH = OUT_DIR / "validation_feedback_memory.json"
STRATEGY_REFLECTION_PATH = OUT_DIR / "strategy_reflection.md"
SKILL_LIBRARY_PATH = ROOT / "knowledge_base" / "skill_library.json"

MEMORY_STORE_PATH = OUT_DIR / "agent_memory_store.json"
MEMORY_INDEX_PATH = OUT_DIR / "memory_retrieval_index.json"
MEMORY_DEMO_PATH = OUT_DIR / "memory_retrieval_demo.json"
MEMORY_CONSOLIDATION_PATH = OUT_DIR / "memory_consolidation_report.md"
MEMORY_SAFETY_POLICY_PATH = OUT_DIR / "memory_safety_policy.json"
MEMORY_REPORT_PATH = OUT_DIR / "memory_system_report.json"

MEMORY_REFERENCE_PATHS = [
    {
        "name": "Generative Agents",
        "url": "https://arxiv.org/abs/2304.03442",
        "borrowed_pattern": "memory stream plus reflection and retrieval",
    },
    {
        "name": "MemGPT",
        "url": "https://arxiv.org/abs/2310.08560",
        "borrowed_pattern": "tiered memory and virtual context management",
    },
    {
        "name": "Reflexion",
        "url": "https://arxiv.org/abs/2303.11366",
        "borrowed_pattern": "feedback converted into reflective episodic memory",
    },
    {
        "name": "Voyager",
        "url": "https://arxiv.org/abs/2305.16291",
        "borrowed_pattern": "skill library reused across future tasks",
    },
]

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "in",
    "into",
    "is",
    "it",
    "of",
    "on",
    "or",
    "the",
    "to",
    "with",
}

RETRIEVAL_QUERIES = [
    {
        "id": "query_oxygen_power_outage",
        "text": "older adult oxygen power outage battery empty utility medical priority",
        "expected_focus": ["oxygen", "power", "emergency", "utility"],
    },
    {
        "id": "query_heatwave_mobility_medication",
        "text": "heatwave medication mobility limitation cooling center transport barrier",
        "expected_focus": ["heat", "cooling", "medication", "transport"],
    },
    {
        "id": "query_shelter_rumor_language_pet",
        "text": "shelter capacity rumor language access pet compatible shelter",
        "expected_focus": ["shelter", "rumor", "language", "pet"],
    },
]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def tokenize(text: str) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9]+", text.lower()) if token not in STOPWORDS and len(token) > 1]


def bounded_score(value: float) -> float:
    return round(max(0.0, min(1.0, value)), 4)


def stable_memory_id(prefix: str, source_id: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9]+", "-", source_id).strip("-").lower()
    return f"{prefix}-{safe}"


def build_episodic_memories(records: list[dict]) -> list[dict]:
    memories = []
    for record in records:
        signals = record.get("triggered_signals", [])
        playbooks = record.get("playbook_ids", [])
        skills = record.get("recommended_skill_ids", [])
        blocked = record.get("blocked_claims", [])
        routes = record.get("official_routes", [])
        importance = 0.45
        importance += 0.2 if record.get("expected_risk") == "high" or record.get("actual_risk") == "high" else 0
        importance += min(len(signals), 6) * 0.03
        importance += min(len(blocked), 5) * 0.03
        importance += 0.08 if skills else 0
        importance += 0.06 if routes else 0
        content = (
            f"Case {record.get('case_id')} from {record.get('source_eval')} validation: "
            f"risk {record.get('actual_risk')}; signals {', '.join(signals) or 'none'}; "
            f"playbooks {', '.join(playbooks) or 'none'}; skills {', '.join(skills) or 'none'}; "
            f"blocked claims {', '.join(blocked) or 'none'}."
        )
        memories.append(
            {
                "memory_id": stable_memory_id("mem-episodic", record.get("case_id", "unknown")),
                "memory_type": "episodic",
                "tier": "working_to_long_term",
                "source": "local_validation_experience",
                "source_eval": record.get("source_eval"),
                "source_case_id": record.get("case_id"),
                "content": content,
                "signals": signals,
                "playbook_ids": playbooks,
                "skill_ids": skills,
                "official_routes": routes,
                "blocked_claims": blocked,
                "importance": bounded_score(importance),
                "recency": 1.0,
                "confidence": 1.0 if record.get("passed") else 0.45,
                "human_review_required": True,
                "promotion_status": "eligible_for_semantic_consolidation" if record.get("passed") else "quarantine_until_review",
                "tokens": tokenize(content + " " + " ".join(signals + playbooks + skills + routes + blocked)),
            }
        )
    return memories


def build_semantic_memories(records: list[dict], feedback: dict) -> list[dict]:
    memories = []
    signal_to_playbooks: dict[str, Counter] = defaultdict(Counter)
    signal_to_skills: dict[str, Counter] = defaultdict(Counter)
    for record in records:
        if not record.get("passed"):
            continue
        for signal in record.get("triggered_signals", []):
            signal_to_playbooks[signal].update(record.get("playbook_ids", []))
            signal_to_skills[signal].update(record.get("recommended_skill_ids", []))

    for signal, counter in sorted(signal_to_playbooks.items()):
        playbooks = [playbook for playbook, _ in counter.most_common(4)]
        skills = [skill for skill, _ in signal_to_skills.get(signal, Counter()).most_common(4)]
        evidence_count = sum(counter.values())
        content = (
            f"When the signal '{signal}' appears, preserve official-resource verification, "
            f"human review when risk is high, and playbook grounding through {', '.join(playbooks) or 'no playbook'}."
        )
        memories.append(
            {
                "memory_id": stable_memory_id("mem-semantic-signal", signal),
                "memory_type": "semantic",
                "tier": "consolidated_long_term",
                "source": "consolidated_validation_feedback",
                "content": content,
                "signals": [signal],
                "playbook_ids": playbooks,
                "skill_ids": skills,
                "evidence_count": evidence_count,
                "importance": bounded_score(0.55 + min(evidence_count, 10) * 0.04),
                "recency": 0.95,
                "confidence": bounded_score(0.7 + min(evidence_count, 10) * 0.03),
                "human_review_required": True,
                "promotion_status": "consolidated_review_required",
                "tokens": tokenize(content + " " + signal + " " + " ".join(playbooks + skills)),
            }
        )

    invariants = feedback.get("safety_invariants", [])
    for invariant in invariants:
        content = f"Safety invariant: {invariant}."
        memories.append(
            {
                "memory_id": stable_memory_id("mem-semantic-invariant", invariant),
                "memory_type": "semantic",
                "tier": "protected_long_term",
                "source": "safety_policy",
                "content": content,
                "signals": [],
                "playbook_ids": [],
                "skill_ids": [],
                "evidence_count": feedback.get("case_count", 0),
                "importance": 1.0,
                "recency": 1.0,
                "confidence": 1.0,
                "human_review_required": True,
                "promotion_status": "protected_invariant",
                "tokens": tokenize(content),
            }
        )
    return memories


def build_procedural_memories(skill_library: dict) -> list[dict]:
    memories = []
    for skill in skill_library.get("skills", []):
        evidence = skill.get("validation_support", {})
        safe_actions = skill.get("safe_actions", [])
        blocked_actions = skill.get("blocked_actions", [])
        content = (
            f"Reusable skill {skill.get('id')}: {skill.get('name')}. "
            f"Safe actions: {'; '.join(safe_actions)}. "
            f"Blocked actions: {'; '.join(blocked_actions)}."
        )
        evidence_count = int(evidence.get("case_count", 0) or 0)
        memories.append(
            {
                "memory_id": stable_memory_id("mem-procedural", skill.get("id", "unknown")),
                "memory_type": "procedural",
                "tier": "human_reviewed_skill_memory",
                "source": "skill_library",
                "content": content,
                "signals": skill.get("trigger_signals", []),
                "playbook_ids": skill.get("trigger_playbooks", []),
                "skill_ids": [skill.get("id")],
                "safe_actions": safe_actions,
                "blocked_actions": blocked_actions,
                "evidence_count": evidence_count,
                "importance": bounded_score(0.65 + min(evidence_count, 8) * 0.04),
                "recency": 0.9,
                "confidence": bounded_score(0.65 + min(evidence_count, 8) * 0.04),
                "human_review_required": True,
                "promotion_status": "reviewed_before_runtime_policy_use",
                "tokens": tokenize(content + " " + " ".join(skill.get("trigger_signals", []))),
            }
        )
    return memories


def build_reflective_memories(strategy_reflection: str, feedback: dict) -> list[dict]:
    paragraphs = [line.strip("- ").strip() for line in strategy_reflection.splitlines() if line.startswith("- ")]
    selected = [line for line in paragraphs if "review" in line.lower() or "preserve" in line.lower() or "future" in line.lower()]
    if not selected:
        selected = ["Preserve current safety contracts and route strategy updates through human review."]
    memories = []
    for idx, note in enumerate(selected[:10], start=1):
        content = f"Reflection note {idx}: {note}"
        memories.append(
            {
                "memory_id": stable_memory_id("mem-reflective", f"note-{idx}"),
                "memory_type": "reflective",
                "tier": "review_only_reflection",
                "source": "strategy_reflection",
                "content": content,
                "signals": [],
                "playbook_ids": [],
                "skill_ids": [],
                "evidence_count": feedback.get("case_count", 0),
                "importance": 0.82,
                "recency": 1.0,
                "confidence": 0.75,
                "human_review_required": True,
                "promotion_status": "review_only",
                "tokens": tokenize(content),
            }
        )
    return memories


def build_memory_store() -> dict:
    if not EXPERIENCE_LEDGER_PATH.exists():
        build_agentic_learning_artifacts(ROOT)
    records = read_jsonl(EXPERIENCE_LEDGER_PATH)
    feedback = read_json(FEEDBACK_MEMORY_PATH)
    skill_library = read_json(SKILL_LIBRARY_PATH)
    reflection = STRATEGY_REFLECTION_PATH.read_text(encoding="utf-8") if STRATEGY_REFLECTION_PATH.exists() else ""
    memories = []
    memories.extend(build_episodic_memories(records))
    memories.extend(build_semantic_memories(records, feedback))
    memories.extend(build_procedural_memories(skill_library))
    memories.extend(build_reflective_memories(reflection, feedback))
    return {
        "schema_version": "resilience-agent-memory-v1",
        "generated_at": date.today().isoformat(),
        "positioning": "offline bounded long-term memory for a disaster triage agent",
        "research_patterns": MEMORY_REFERENCE_PATHS,
        "memory_tiers": {
            "episodic": "case-level validation experiences",
            "semantic": "consolidated safety facts and signal-to-policy associations",
            "procedural": "reusable human-reviewed skills",
            "reflective": "review-only strategy notes from validation feedback",
        },
        "safety_boundary": {
            "network_access": False,
            "autonomous_policy_update": False,
            "external_side_effects": "none",
            "human_review_required": True,
        },
        "memories": memories,
    }


def build_index(memory_store: dict) -> dict:
    inverted: dict[str, set[str]] = defaultdict(set)
    type_counts = Counter()
    for memory in memory_store["memories"]:
        type_counts[memory["memory_type"]] += 1
        for token in memory.get("tokens", []):
            inverted[token].add(memory["memory_id"])
    return {
        "schema_version": "resilience-memory-index-v1",
        "memory_count": len(memory_store["memories"]),
        "memory_type_counts": dict(type_counts),
        "retrieval_formula": "0.55*relevance + 0.2*importance + 0.15*confidence + 0.1*recency, safety invariants are pinned",
        "inverted_index": {token: sorted(ids) for token, ids in sorted(inverted.items())},
    }


def score_memory(query_tokens: list[str], memory: dict) -> dict:
    memory_tokens = set(memory.get("tokens", []))
    overlap = sorted(set(query_tokens) & memory_tokens)
    relevance = len(overlap) / max(1, len(set(query_tokens)))
    raw_score = 0.55 * relevance + 0.2 * memory.get("importance", 0) + 0.15 * memory.get("confidence", 0) + 0.1 * memory.get("recency", 0)
    if memory.get("promotion_status") == "protected_invariant":
        raw_score += 0.08
    return {
        "memory_id": memory["memory_id"],
        "memory_type": memory["memory_type"],
        "score": round(raw_score, 4),
        "overlap": overlap,
        "importance": memory.get("importance", 0),
        "confidence": memory.get("confidence", 0),
        "recency": memory.get("recency", 0),
        "human_review_required": memory.get("human_review_required", True),
        "content": memory["content"],
    }


def retrieve(memory_store: dict, query: str, limit: int = 6) -> list[dict]:
    query_tokens = tokenize(query)
    scored = [score_memory(query_tokens, memory) for memory in memory_store["memories"]]
    scored.sort(key=lambda item: (-item["score"], item["memory_type"], item["memory_id"]))
    return scored[:limit]


def build_retrieval_demo(memory_store: dict) -> dict:
    examples = []
    for query in RETRIEVAL_QUERIES:
        examples.append(
            {
                "query_id": query["id"],
                "query": query["text"],
                "expected_focus": query["expected_focus"],
                "top_memories": retrieve(memory_store, query["text"], limit=6),
            }
        )
    return {
        "schema_version": "memory-retrieval-demo-v1",
        "mode": "offline lexical retrieval with importance/confidence/recency weighting",
        "examples": examples,
    }


def build_consolidation_report(memory_store: dict) -> str:
    memories = memory_store["memories"]
    type_counts = Counter(memory["memory_type"] for memory in memories)
    promoted = [memory for memory in memories if memory.get("promotion_status") in {"consolidated_review_required", "reviewed_before_runtime_policy_use", "protected_invariant"}]
    quarantine = [memory for memory in memories if memory.get("promotion_status") == "quarantine_until_review"]
    avg_importance = sum(memory.get("importance", 0) for memory in memories) / max(1, len(memories))
    duplicate_groups = defaultdict(list)
    for memory in memories:
        key = " ".join(sorted(set(memory.get("tokens", [])) & {"shelter", "oxygen", "heat", "transport", "language", "pet", "rumor"}))
        if key:
            duplicate_groups[key].append(memory["memory_id"])
    repeated_topics = {key: ids for key, ids in duplicate_groups.items() if len(ids) > 2}
    lines = [
        "# Memory Consolidation Report",
        "",
        "## Summary",
        "",
        f"- Total memories: {len(memories)}",
        f"- Type counts: {dict(type_counts)}",
        f"- Promoted/protected memories: {len(promoted)}",
        f"- Quarantined memories: {len(quarantine)}",
        f"- Average importance: {avg_importance:.3f}",
        "",
        "## Consolidation Policy",
        "",
        "- Episodic memories are raw validation experiences.",
        "- Semantic memories are promoted only from passing local validation patterns.",
        "- Procedural memories come from the human-reviewed skill library.",
        "- Reflective memories remain review-only and cannot update runtime policy automatically.",
        "- Safety invariants are pinned and cannot be decayed by recency.",
        "",
        "## Repeated Topics",
        "",
    ]
    if repeated_topics:
        for topic, ids in sorted(repeated_topics.items()):
            lines.append(f"- {topic}: {len(ids)} related memories")
    else:
        lines.append("- No high-duplication topic groups detected.")
    lines.extend(
        [
            "",
            "## Forgetting and Decay",
            "",
            "- Passed high-risk safety memories are retained.",
            "- Low-importance memories can be summarized after reviewer approval.",
            "- Failed memories are quarantined until a reviewer decides whether to add a new validation case.",
            "- No memory is allowed to weaken emergency-service, diagnosis, capacity, transport, or human-review constraints.",
        ]
    )
    return "\n".join(lines) + "\n"


def build_safety_policy(memory_store: dict) -> dict:
    protected_ids = [memory["memory_id"] for memory in memory_store["memories"] if memory.get("promotion_status") == "protected_invariant"]
    return {
        "schema_version": "memory-safety-policy-v1",
        "network_access": False,
        "external_side_effects": "none",
        "autonomous_policy_update": False,
        "human_review_required_for": [
            "memory promotion into runtime policy",
            "new skill activation",
            "tool whitelist expansion",
            "high-risk triage behavior changes",
        ],
        "blocked_memory_effects": [
            "call emergency services",
            "book shelters",
            "diagnose conditions",
            "promise live capacity",
            "promise transport availability",
            "downgrade human review",
        ],
        "protected_memory_ids": protected_ids,
    }


def build_agent_memory_artifacts(root: Path | None = None) -> dict:
    del root
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    memory_store = build_memory_store()
    index = build_index(memory_store)
    retrieval_demo = build_retrieval_demo(memory_store)
    safety_policy = build_safety_policy(memory_store)
    consolidation = build_consolidation_report(memory_store)

    write_json(MEMORY_STORE_PATH, memory_store)
    write_json(MEMORY_INDEX_PATH, index)
    write_json(MEMORY_DEMO_PATH, retrieval_demo)
    write_json(MEMORY_SAFETY_POLICY_PATH, safety_policy)
    MEMORY_CONSOLIDATION_PATH.write_text(consolidation, encoding="utf-8")

    type_counts = Counter(memory["memory_type"] for memory in memory_store["memories"])
    retrieval_ready = all(example["top_memories"] for example in retrieval_demo["examples"])
    report = {
        "ready": bool(memory_store["memories"]) and retrieval_ready and bool(safety_policy["protected_memory_ids"]),
        "artifacts": {
            "memory_store": str(MEMORY_STORE_PATH.relative_to(ROOT)),
            "retrieval_index": str(MEMORY_INDEX_PATH.relative_to(ROOT)),
            "retrieval_demo": str(MEMORY_DEMO_PATH.relative_to(ROOT)),
            "consolidation_report": str(MEMORY_CONSOLIDATION_PATH.relative_to(ROOT)),
            "safety_policy": str(MEMORY_SAFETY_POLICY_PATH.relative_to(ROOT)),
        },
        "memory_count": len(memory_store["memories"]),
        "memory_type_counts": dict(type_counts),
        "retrieval_demo_count": len(retrieval_demo["examples"]),
        "protected_invariant_count": len(safety_policy["protected_memory_ids"]),
        "research_patterns": [item["name"] for item in MEMORY_REFERENCE_PATHS],
        "safety_boundary": "offline only; human-reviewed; no autonomous real-world action or policy update",
    }
    write_json(MEMORY_REPORT_PATH, report)
    return report


def main() -> None:
    report = build_agent_memory_artifacts()
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
