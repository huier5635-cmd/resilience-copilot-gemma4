"""Check that the Kaggle writeup candidate is concise and evidence-complete."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_WRITEUP = ROOT / "docs" / "final_kaggle_writeup_EXP020.md"
OUT = ROOT / "outputs" / "local_validation" / "writeup_readiness.json"


REQUIRED_TERMS = [
    "Gemma 4",
    "Resilience Copilot",
    "15/15",
    "Audit trace",
    "Human review reason",
    "Source verification ledger",
    "Transfer brief",
    "PB-SHELTER-CAPACITY",
    "official local channels",
    "qualified interpreters",
]

REQUIRED_LINKS = [
    "https://huier5635-cmd.github.io/resilience-copilot-gemma4/",
    "https://github.com/huier5635-cmd/resilience-copilot-gemma4",
    "https://youtu.be/CmqCV8Ic9cY",
    "https://www.kaggle.com/code/zhenhuier/notebook5022dfd167",
]


def count_words(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)?", text))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--writeup", type=Path, default=DEFAULT_WRITEUP)
    parser.add_argument("--max-words", type=int, default=1500)
    parser.add_argument("--output", type=Path, default=OUT)
    args = parser.parse_args()

    path = args.writeup if args.writeup.is_absolute() else ROOT / args.writeup
    text = path.read_text(encoding="utf-8")
    word_count = count_words(text)
    term_hits = {term: term in text for term in REQUIRED_TERMS}
    link_hits = {link: link in text for link in REQUIRED_LINKS}
    result = {
        "path": str(path.relative_to(ROOT)),
        "word_count": word_count,
        "max_words": args.max_words,
        "within_limit": word_count <= args.max_words,
        "required_terms": term_hits,
        "required_links": link_hits,
        "ready": word_count <= args.max_words and all(term_hits.values()) and all(link_hits.values()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"ready": result["ready"], "word_count": word_count, "output": str(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
