"""Check judge-facing evidence for the final Gemma 4 Good submission."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
OUTPUT = OUT_DIR / "judging_packet.json"

REQUIRED_PATHS = {
    "final_writeup": "docs/final_kaggle_writeup_EXP020.md",
    "judge_matrix": "docs/judging_evidence_matrix_EXP021.md",
    "evidence_report": "outputs/local_validation/evidence_report.md",
    "writeup_readiness": "outputs/local_validation/writeup_readiness.json",
    "submission_bundle": "outputs/submission_assets/resilience_copilot_submission_bundle.zip",
    "pitch_deck": "outputs/submission_assets/resilience_copilot_pitch_v2.pptx",
    "static_demo_zip": "outputs/submission_assets/public_demo_static.zip",
    "audit_trace_screenshot": "outputs/local_validation/public_demo_audit_trace_crop_20260514.png",
    "gemma4_runtime_evidence": "outputs/local_validation/kaggle_gemma4_evidence_20260513.md",
}

REQUIRED_LINKS = {
    "public_demo": "https://huier5635-cmd.github.io/resilience-copilot-gemma4/",
    "public_code": "https://github.com/huier5635-cmd/resilience-copilot-gemma4",
    "video": "https://youtu.be/CmqCV8Ic9cY",
    "kaggle_notebook": "https://www.kaggle.com/code/zhenhuier/notebook5022dfd167",
}

WRITEUP_TERMS = [
    "Resilience Copilot",
    "Gemma 4",
    "Audit trace",
    "13/13",
    "Human review reason",
    "official local channels",
    "qualified interpreters",
]

MATRIX_TERMS = [
    "Impact and vision",
    "Technical depth",
    "Gemma 4 runtime evidence",
    "Validation",
    "Original branch",
    "Final Submission Slot Plan",
    "What Not To Overclaim",
]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def case_ready(name: str) -> bool:
    data = read_json(OUT_DIR / name)
    return data.get("passed") == data.get("total") and data.get("total", 0) > 0


def main() -> None:
    final_writeup = read_text(ROOT / "docs" / "final_kaggle_writeup_EXP020.md")
    matrix = read_text(ROOT / "docs" / "judging_evidence_matrix_EXP021.md")
    writeup_readiness = read_json(OUT_DIR / "writeup_readiness.json")
    path_checks = {
        name: {"path": path, "exists": (ROOT / path).exists()}
        for name, path in REQUIRED_PATHS.items()
    }
    link_checks = {
        name: {
            "url": url,
            "in_writeup": url in final_writeup,
            "in_matrix": url in matrix,
        }
        for name, url in REQUIRED_LINKS.items()
    }
    term_checks = {
        "writeup": {term: term in final_writeup for term in WRITEUP_TERMS},
        "matrix": {term: term in matrix for term in MATRIX_TERMS},
    }
    validation = {
        "demo": case_ready("demo_eval.json"),
        "holdout": case_ready("holdout_eval.json"),
        "stress": case_ready("stress_eval.json"),
        "writeup_readiness": bool(writeup_readiness.get("ready")),
    }
    ready = (
        all(item["exists"] for item in path_checks.values())
        and all(item["in_writeup"] and item["in_matrix"] for item in link_checks.values())
        and all(term_checks["writeup"].values())
        and all(term_checks["matrix"].values())
        and all(validation.values())
    )
    report = {
        "ready": ready,
        "paths": path_checks,
        "links": link_checks,
        "terms": term_checks,
        "validation": validation,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"ready": ready, "output": str(OUTPUT.relative_to(ROOT))}, ensure_ascii=False))


if __name__ == "__main__":
    main()
