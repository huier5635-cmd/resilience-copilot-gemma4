"""Build offline agentic learning artifacts from local validation feedback."""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
SKILL_LIBRARY_PATH = ROOT / "knowledge_base" / "skill_library.json"

EVAL_FILES = {
    "demo": OUT_DIR / "demo_eval.json",
    "holdout": OUT_DIR / "holdout_eval.json",
    "stress": OUT_DIR / "stress_eval.json",
}

EXPERIENCE_LEDGER_PATH = OUT_DIR / "experience_ledger.jsonl"
FEEDBACK_MEMORY_PATH = OUT_DIR / "validation_feedback_memory.json"
STRATEGY_REFLECTION_PATH = OUT_DIR / "strategy_reflection.md"
TOOL_SANDBOX_PATH = OUT_DIR / "tool_calling_sandbox_demo.json"
VOYAGER_LOOP_PATH = OUT_DIR / "voyager_style_learning_loop.json"
AGENTIC_REPORT_PATH = OUT_DIR / "agentic_learning_report.json"

SKILL_DEFINITIONS = [
    {
        "id": "SKILL-LIFE-SAFETY-ESCALATION",
        "name": "life-safety escalation",
        "trigger_playbooks": ["PB-LIFE-SAFETY-ESCALATE"],
        "trigger_signals": ["oxygen", "electrical", "floodwater", "pregnancy", "child cold exposure"],
        "safe_actions": [
            "route immediate danger through emergency services or official local responders",
            "collect callback, location, device, medication, and mobility constraints for handoff",
            "keep final routing with a human responder",
        ],
        "blocked_actions": ["wait-and-see advice for urgent device failure", "medical diagnosis", "capacity or transport guarantees"],
    },
    {
        "id": "SKILL-RUMOR-QUARANTINE",
        "name": "rumor quarantine and source verification",
        "trigger_playbooks": ["PB-SHELTER-CAPACITY"],
        "trigger_signals": ["unverified shelter capacity rumor", "evacuation or shelter need"],
        "safe_actions": [
            "label social media or word-of-mouth capacity claims as unverified",
            "route capacity checks through shelter operations or emergency management",
            "say what is known, unknown, and being checked",
        ],
        "blocked_actions": ["repeat unverified bed counts", "promise live shelter capacity"],
    },
    {
        "id": "SKILL-LANGUAGE-ACCESS-HANDOFF",
        "name": "qualified language access handoff",
        "trigger_playbooks": ["PB-LANGUAGE-ACCESS"],
        "trigger_signals": ["language access barrier"],
        "safe_actions": [
            "request qualified interpretation for medical, legal, registration, and shelter details",
            "record preferred language in the transfer brief",
            "confirm understanding before routing",
        ],
        "blocked_actions": ["use children as interpreters for safety-critical details"],
    },
    {
        "id": "SKILL-HEATWAVE-ROUTING",
        "name": "heatwave and cooling-center routing",
        "trigger_playbooks": ["PB-HEAT-COOLING-CENTER"],
        "trigger_signals": ["cooling center", "heat illness", "extreme heat"],
        "safe_actions": [
            "route heat exposure through public health or emergency-management heat channels",
            "verify cooling-center hours, accessible intake, hydration support, and medication storage",
            "record transport barriers before suggesting routing",
        ],
        "blocked_actions": ["promise cooling-center capacity", "claim medical safety without confirmation"],
    },
    {
        "id": "SKILL-ACCESSIBLE-TRANSPORT",
        "name": "accessible transport routing",
        "trigger_playbooks": ["PB-ACCESSIBLE-TRANSPORT"],
        "trigger_signals": ["transport barrier"],
        "safe_actions": [
            "route transport through official logistics or responder channels",
            "avoid flooded roads and unverified routes",
            "carry transport uncertainty into the transfer brief",
        ],
        "blocked_actions": ["suggest informal travel through unsafe roads", "guarantee vehicle availability"],
    },
    {
        "id": "SKILL-PET-COMPATIBLE-SHELTER",
        "name": "pet-compatible shelter check",
        "trigger_playbooks": ["PB-PET-SHELTER"],
        "trigger_signals": ["pet-compatible shelter needed"],
        "safe_actions": [
            "verify pet policy, species or size limits, carrier needs, and documentation",
            "route through animal services or shelter pet desk",
        ],
        "blocked_actions": ["assume every shelter accepts pets"],
    },
    {
        "id": "SKILL-ICS-TRANSFER-BRIEF",
        "name": "ICS-style transfer brief",
        "trigger_playbooks": [],
        "trigger_signals": ["transfer brief", "human review"],
        "safe_actions": [
            "summarize incident snapshot, objectives, constraints, resources, communications, and unresolved questions",
            "carry source verification and safety constraints into shift handoff",
        ],
        "blocked_actions": ["drop unknowns from the handoff", "hide unsupported claims"],
    },
]

TOOL_WHITELIST = [
    {
        "id": "TOOL-OFFICIAL-EMERGENCY-ROUTE-CHECK",
        "name": "official emergency route check",
        "matches_route_terms": ["Emergency services", "utility emergency line", "Local emergency management"],
        "mode": "offline sandbox",
        "allowed_result": "requires human responder or official channel confirmation",
    },
    {
        "id": "TOOL-SHELTER-OPS-VERIFY",
        "name": "shelter operations verification",
        "matches_route_terms": ["Shelter operations desk"],
        "mode": "offline sandbox",
        "allowed_result": "capacity remains unknown until official shelter staff confirm",
    },
    {
        "id": "TOOL-MEDICAL-CONTINUITY-ROUTE",
        "name": "medical continuity route check",
        "matches_route_terms": ["Medical triage", "clinic", "pharmacy", "care coordinator"],
        "mode": "offline sandbox",
        "allowed_result": "route to clinical or pharmacy confirmation without diagnosis",
    },
    {
        "id": "TOOL-TRANSPORT-LOGISTICS-CHECK",
        "name": "transport logistics check",
        "matches_route_terms": ["transport desk", "emergency management logistics"],
        "mode": "offline sandbox",
        "allowed_result": "transport availability remains unknown until official logistics confirms",
    },
    {
        "id": "TOOL-LANGUAGE-ACCESS-CHECK",
        "name": "qualified interpreter availability check",
        "matches_route_terms": ["Language access", "interpreter"],
        "mode": "offline sandbox",
        "allowed_result": "qualified interpretation required for safety-critical details",
    },
    {
        "id": "TOOL-HEAT-RESPONSE-CHECK",
        "name": "public health heat-response check",
        "matches_route_terms": ["Public health heat line", "cooling-center coordinator"],
        "mode": "offline sandbox",
        "allowed_result": "cooling-center hours and intake remain unknown until official confirmation",
    },
]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def split_pipe_value(value: str) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split("|") if item.strip()]


def audit_value(response: str, key: str) -> str:
    prefix = f"- {key}="
    for line in response.splitlines():
        if line.startswith(prefix):
            return line[len(prefix) :].strip()
    return ""


def skill_ids_for(playbook_ids: list[str], signals: list[str], response: str) -> list[str]:
    signal_text = " | ".join(signals).lower()
    response_text = response.lower()
    skill_ids: list[str] = []
    for skill in SKILL_DEFINITIONS:
        by_playbook = any(playbook in playbook_ids for playbook in skill["trigger_playbooks"])
        by_signal = any(term.lower() in signal_text for term in skill["trigger_signals"])
        by_response = skill["id"] == "SKILL-ICS-TRANSFER-BRIEF" and "transfer brief" in response_text
        if by_playbook or by_signal or by_response:
            skill_ids.append(skill["id"])
    return skill_ids


def tool_calls_for(case_id: str, official_routes: list[str]) -> list[dict]:
    selected = []
    route_text = " | ".join(official_routes)
    for tool in TOOL_WHITELIST:
        if any(term in route_text for term in tool["matches_route_terms"]):
            selected.append(
                {
                    "case_id": case_id,
                    "tool_id": tool["id"],
                    "tool_name": tool["name"],
                    "mode": tool["mode"],
                    "simulated_result": tool["allowed_result"],
                    "external_side_effects": "none",
                    "human_review_required": True,
                }
            )
    return selected


def build_experience_records() -> list[dict]:
    records: list[dict] = []
    today = date.today().isoformat()
    for eval_name, path in EVAL_FILES.items():
        data = read_json(path)
        for result in data.get("results", []):
            response = result.get("response", "")
            signals = split_pipe_value(audit_value(response, "signals"))
            playbook_ids = split_pipe_value(audit_value(response, "playbook_ids"))
            official_routes = split_pipe_value(audit_value(response, "official_routes"))
            blocked_claims = split_pipe_value(audit_value(response, "blocked_claims"))
            response_contract = split_pipe_value(audit_value(response, "response_contract"))
            missing_required_terms = [term for term, ok in result.get("include_hits", {}).items() if not ok]
            forbidden_claim_hits = [term for term, hit in result.get("forbidden_hits", {}).items() if hit]
            passed = bool(result.get("passed"))
            skill_ids = skill_ids_for(playbook_ids, signals, response)
            record = {
                "schema_version": "agentic-learning-v1",
                "recorded_at": today,
                "source_eval": eval_name,
                "case_id": result.get("id", ""),
                "passed": passed,
                "expected_risk": result.get("expected_risk", ""),
                "actual_risk": result.get("actual_risk", ""),
                "risk_ok": bool(result.get("risk_ok")),
                "missing_required_terms": missing_required_terms,
                "forbidden_claim_hits": forbidden_claim_hits,
                "triggered_signals": signals,
                "playbook_ids": playbook_ids,
                "official_routes": official_routes,
                "blocked_claims": blocked_claims,
                "response_contract": response_contract,
                "recommended_skill_ids": skill_ids,
                "feedback_summary": "passed local validation; preserve this behavior" if passed else "needs human-reviewed strategy update before reuse",
                "next_strategy": "retain_and_monitor" if passed else "review_failure_and_add_targeted_case",
                "safety_boundary": "offline learning only; no live external action, diagnosis, booking, or capacity promise",
            }
            records.append(record)
    return records


def build_feedback_memory(records: list[dict]) -> dict:
    signal_counts = Counter(signal for record in records for signal in record["triggered_signals"])
    playbook_counts = Counter(playbook for record in records for playbook in record["playbook_ids"])
    skill_counts = Counter(skill for record in records for skill in record["recommended_skill_ids"])
    tool_counts = Counter(
        tool["tool_id"]
        for record in records
        for tool in tool_calls_for(record["case_id"], record["official_routes"])
    )
    by_eval: dict[str, dict[str, int]] = defaultdict(lambda: {"passed": 0, "total": 0})
    for record in records:
        by_eval[record["source_eval"]]["total"] += 1
        by_eval[record["source_eval"]]["passed"] += int(record["passed"])
    failed = [record for record in records if not record["passed"]]
    return {
        "schema_version": "validation-feedback-memory-v1",
        "source": "local demo/holdout/stress validation feedback",
        "case_count": len(records),
        "passed_count": sum(1 for record in records if record["passed"]),
        "failed_count": len(failed),
        "pass_rate": round(sum(1 for record in records if record["passed"]) / len(records), 4) if records else 0,
        "by_eval": dict(by_eval),
        "failed_cases": [
            {
                "case_id": record["case_id"],
                "missing_required_terms": record["missing_required_terms"],
                "forbidden_claim_hits": record["forbidden_claim_hits"],
                "next_strategy": record["next_strategy"],
            }
            for record in failed
        ],
        "recurrent_signals": signal_counts.most_common(),
        "playbook_usage": playbook_counts.most_common(),
        "skill_usage": skill_counts.most_common(),
        "tool_sandbox_usage": tool_counts.most_common(),
        "learned_preferences": [
            "preserve official-routes-first responses for shelter, transport, medical, heat, and language cases",
            "carry blocked claims into audit trace and structured export",
            "keep human review explicit for high-risk and resource-uncertain cases",
            "treat repeated passing routines as reusable skills only after human review",
        ],
        "safety_invariants": [
            "no live external action",
            "no emergency-service replacement",
            "no diagnosis",
            "no shelter-capacity promise",
            "no transport-availability promise",
            "human review required before policy changes",
        ],
        "ready": len(records) > 0 and not failed,
    }


def build_skill_library(records: list[dict]) -> dict:
    skill_counts = Counter(skill for record in records for skill in record["recommended_skill_ids"])
    playbook_counts = Counter(playbook for record in records for playbook in record["playbook_ids"])
    skills = []
    for skill in SKILL_DEFINITIONS:
        evidence_cases = [record["case_id"] for record in records if skill["id"] in record["recommended_skill_ids"]]
        skills.append(
            {
                **skill,
                "human_review_status": "review_required_before_policy_update",
                "validation_support": {
                    "case_count": len(evidence_cases),
                    "passed_case_count": sum(1 for record in records if skill["id"] in record["recommended_skill_ids"] and record["passed"]),
                    "example_case_ids": evidence_cases[:5],
                },
            }
        )
    return {
        "schema_version": "resilience-skill-library-v1",
        "source": "generated from local validation experience ledger",
        "human_review_required": True,
        "auto_apply_policy_updates": False,
        "playbook_usage": playbook_counts.most_common(),
        "skill_usage": skill_counts.most_common(),
        "skills": skills,
        "blocked_global_actions": [
            "autonomous emergency calls",
            "shelter booking",
            "medical diagnosis",
            "live capacity promises",
            "transport availability promises",
        ],
    }


def build_tool_sandbox(records: list[dict]) -> dict:
    calls = [call for record in records for call in tool_calls_for(record["case_id"], record["official_routes"])]
    return {
        "schema_version": "tool-calling-sandbox-v1",
        "mode": "offline deterministic simulation",
        "network_access": False,
        "external_side_effects": "none",
        "purpose": "show how future tool calling would stay inside approved official-resource checks",
        "whitelist": TOOL_WHITELIST,
        "simulated_calls": calls,
        "blocked_actions": [
            "call 911 or emergency services automatically",
            "book shelter beds",
            "claim live facility capacity",
            "diagnose or provide treatment",
            "guarantee transport availability",
        ],
    }


def build_strategy_reflection(records: list[dict], memory: dict, skill_library: dict, tool_sandbox: dict) -> str:
    failed_count = memory["failed_count"]
    status_line = "All local validation cases passed; preserve current safety contracts." if failed_count == 0 else "Some cases failed; require focused human review before policy changes."
    top_signals = ", ".join(item for item, _ in memory["recurrent_signals"][:5]) or "none"
    top_skills = ", ".join(item for item, _ in memory["skill_usage"][:5]) or "none"
    lines = [
        "# Strategy Reflection",
        "",
        "## Summary",
        "",
        f"- Source: local validation feedback from {memory['case_count']} cases.",
        f"- Pass rate: {memory['passed_count']} / {memory['case_count']}.",
        f"- Status: {status_line}",
        "- Mode: offline learning sidecar only; no live external action.",
        "",
        "## Learned Patterns",
        "",
        f"- Recurrent signals: {top_signals}.",
        f"- Reusable skills supported by validation: {top_skills}.",
        "- Official-route verification and blocked-claim carryover remain the strongest safety pattern.",
        "- Transfer Brief and Audit Trace give each experience record enough structure for review.",
        "",
        "## Strategy Updates for Human Review",
        "",
        "- Promote repeated passing routines into the skill library only after reviewer approval.",
        "- Keep high-risk oxygen, electrical, heat, insulin, dialysis, transport, and language-access cases on human-review paths.",
        "- Add future adversarial validation around mixed rumors, multilingual medication continuity, and conflicting transport information.",
        "- Keep tool calling in sandbox mode until an official-resource whitelist and audit log are reviewed.",
        "",
        "## Safety Boundary",
        "",
        "- No autonomous emergency calls, shelter booking, diagnosis, live capacity promises, or transport guarantees.",
        "- No automatic policy update is applied by this reflection.",
        "- Every strategy change remains review-only until a human accepts it.",
        "",
        "## Artifact Links",
        "",
        f"- Experience ledger: `{EXPERIENCE_LEDGER_PATH.relative_to(ROOT)}`",
        f"- Feedback memory: `{FEEDBACK_MEMORY_PATH.relative_to(ROOT)}`",
        f"- Skill library: `{SKILL_LIBRARY_PATH.relative_to(ROOT)}`",
        f"- Tool sandbox: `{TOOL_SANDBOX_PATH.relative_to(ROOT)}`",
        f"- Voyager-style loop: `{VOYAGER_LOOP_PATH.relative_to(ROOT)}`",
    ]
    return "\n".join(lines) + "\n"


def build_voyager_loop(records: list[dict], memory: dict) -> dict:
    return {
        "schema_version": "voyager-style-loop-v1",
        "positioning": "bounded learning loop inspired by Voyager, adapted for disaster-relief safety constraints",
        "implemented_components": {
            "experience_ledger": True,
            "validation_feedback_memory": True,
            "strategy_reflection": True,
            "skill_library": True,
            "tool_calling_sandbox": True,
            "online_api_calls": False,
            "autonomous_real_world_actions": False,
        },
        "loop": [
            "observe local validation outcomes",
            "record each case as an experience ledger entry",
            "summarize recurrent signals, playbooks, skills, and tool-sandbox needs",
            "reflect on strategy updates for human review",
            "refresh the human-reviewed skill library",
            "plan next validation cases without changing core policy automatically",
        ],
        "current_memory": {
            "case_count": memory["case_count"],
            "passed_count": memory["passed_count"],
            "failed_count": memory["failed_count"],
            "ready": memory["ready"],
        },
        "next_iteration_policy": {
            "allowed": ["add local validation cases", "propose skill updates", "propose playbook review notes", "simulate whitelisted tool calls"],
            "blocked": ["autonomous emergency calls", "shelter booking", "diagnosis", "live availability claims"],
            "human_review_required": True,
        },
    }


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def build_agentic_learning_artifacts(root: Path | None = None) -> dict:
    # The root argument is accepted so run_local_validation can call this in extracted bundles.
    del root
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    records = build_experience_records()
    EXPERIENCE_LEDGER_PATH.write_text(
        "\n".join(json.dumps(record, ensure_ascii=False) for record in records) + ("\n" if records else ""),
        encoding="utf-8",
    )
    memory = build_feedback_memory(records)
    skill_library = build_skill_library(records)
    tool_sandbox = build_tool_sandbox(records)
    voyager_loop = build_voyager_loop(records, memory)
    reflection = build_strategy_reflection(records, memory, skill_library, tool_sandbox)

    write_json(FEEDBACK_MEMORY_PATH, memory)
    write_json(SKILL_LIBRARY_PATH, skill_library)
    write_json(TOOL_SANDBOX_PATH, tool_sandbox)
    write_json(VOYAGER_LOOP_PATH, voyager_loop)
    STRATEGY_REFLECTION_PATH.write_text(reflection, encoding="utf-8")

    report = {
        "ready": memory["ready"],
        "artifacts": {
            "experience_ledger": str(EXPERIENCE_LEDGER_PATH.relative_to(ROOT)),
            "validation_feedback_memory": str(FEEDBACK_MEMORY_PATH.relative_to(ROOT)),
            "strategy_reflection": str(STRATEGY_REFLECTION_PATH.relative_to(ROOT)),
            "skill_library": str(SKILL_LIBRARY_PATH.relative_to(ROOT)),
            "tool_calling_sandbox": str(TOOL_SANDBOX_PATH.relative_to(ROOT)),
            "voyager_style_learning_loop": str(VOYAGER_LOOP_PATH.relative_to(ROOT)),
        },
        "case_count": memory["case_count"],
        "passed_count": memory["passed_count"],
        "failed_count": memory["failed_count"],
        "tool_sandbox_call_count": len(tool_sandbox["simulated_calls"]),
        "skill_count": len(skill_library["skills"]),
        "safety_boundary": "offline only; human-reviewed; no real-world autonomous action",
    }
    write_json(AGENTIC_REPORT_PATH, report)
    return report


def main() -> None:
    report = build_agentic_learning_artifacts()
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
