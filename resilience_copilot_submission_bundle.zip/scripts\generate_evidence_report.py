"""Generate a concise local evidence markdown report."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "outputs" / "local_validation"
REPORT = OUT_DIR / "evidence_report.md"


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def main() -> None:
    local = read_json(OUT_DIR / "local_validation_report.json")
    demo = read_json(OUT_DIR / "demo_eval.json")
    holdout = read_json(OUT_DIR / "holdout_eval.json")
    kaggle_evidence = OUT_DIR / "kaggle_gemma4_evidence_20260513.md"
    local_demo = OUT_DIR / "local_demo_7861_20260513.png"
    kaggle_draft = OUT_DIR / "kaggle_writeup_draft_latest_20260513.png"
    video_draft = ROOT / "outputs" / "submission_assets" / "resilience_copilot_caption_video_20260513.webm"
    static_demo = ROOT / "outputs" / "submission_assets" / "public_demo_static.zip"
    runtime_status = "ready" if kaggle_evidence.exists() else "template ready; final screenshot/log still needs to be attached after Kaggle run"
    lines = [
        "# Local Evidence Report",
        "",
        "## Gate",
        "",
        f"- Ready to submit: `{local.get('ready_to_submit', False)}`",
        f"- Demo cases: {demo.get('passed', 0)} / {demo.get('total', 0)}",
        f"- Holdout cases: {holdout.get('passed', 0)} / {holdout.get('total', 0)}",
        "",
        "## Gemma 4 Runtime",
        "",
        "- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`",
        "- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`",
        f"- Status: {runtime_status}.",
        "",
        "## Local Demo",
        "",
        f"- Screenshot: `{local_demo.relative_to(ROOT)}`" if local_demo.exists() else "- Screenshot: missing",
        f"- Static package: `{static_demo.relative_to(ROOT)}`" if static_demo.exists() else "- Static package: missing",
        "",
        "## Kaggle Draft",
        "",
        "- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`",
        "- Checklist: 6/7 complete.",
        "- Submit test: blocked by missing YouTube video; no final submission was created.",
        f"- Screenshot: `{kaggle_draft.relative_to(ROOT)}`" if kaggle_draft.exists() else "- Screenshot: missing",
        "",
        "## Video",
        "",
        f"- Local draft: `{video_draft.relative_to(ROOT)}`" if video_draft.exists() else "- Local draft: missing",
        "- Public YouTube URL: missing.",
        "",
        "## Missing Assets",
        "",
    ]
    checks = local.get("submission_assets", {}).get("checks", {})
    for name, info in checks.items():
        if not info.get("ready"):
            lines.append(f"- {name}: {info.get('status')}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str(REPORT))


if __name__ == "__main__":
    main()
