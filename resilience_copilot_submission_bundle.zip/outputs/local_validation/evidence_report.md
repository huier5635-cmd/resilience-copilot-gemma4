# Local Evidence Report

## Gate

- Ready to submit: `True`
- Demo cases: 2 / 2
- Holdout cases: 2 / 2
- Stress cases: 6 / 6

## Original Enhancement

- Language access sidecar: detects preferred language needs and requires a qualified interpreter for safety-critical details.
- Responder handoff: produces a compact operational summary for volunteer or case-worker transfer.
- Official resource checks: routes shelter, medical, transport, animal-service, interpreter, utility, and emergency needs to official verification points without inventing capacity.
- UI evidence: local Flask demo and static GitHub Pages demo expose the language-aware handoff and official-resource-routing paths.

## Gemma 4 Runtime

- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`
- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`
- Status: ready.

## Local Demo

- Screenshot: `outputs\local_validation\local_demo_resource_routing_7863_20260514.png`
- Static package: `outputs\submission_assets\public_demo_static.zip`
- Public code repo: `https://github.com/huier5635-cmd/resilience-copilot-gemma4`
- Public live demo: `https://huier5635-cmd.github.io/resilience-copilot-gemma4/`
- Public demo screenshot: `outputs\local_validation\github_pages_resource_routing_20260514.png`
- Pitch deck: `outputs\submission_assets\resilience_copilot_pitch_v2.pptx`

## Kaggle Draft

- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`
- Checklist: 7/7 complete.
- Submission status: submitted_refreshed.
- Final submission created: `True`
- Screenshot: `outputs\local_validation\kaggle_official_resource_submitted_verified_20260514.png`

## Video

- Local draft: `outputs\submission_assets\resilience_copilot_caption_video_20260513.webm`
- Public YouTube URL: `https://youtu.be/CmqCV8Ic9cY`

## Missing Assets

