# Local Evidence Report

## Gate

- Ready to submit: `True`
- Demo cases: 2 / 2
- Holdout cases: 2 / 2
- Stress cases: 14 / 14
- Writeup readiness: `True` (1026 / 1500 words)
- Judging packet: `True`

## Original Enhancement

- Language access sidecar: detects preferred language needs and requires a qualified interpreter for safety-critical details.
- Responder handoff: produces a compact operational summary for volunteer or case-worker transfer.
- Official resource checks: routes shelter, medical, transport, animal-service, interpreter, utility, and emergency needs to official verification points without inventing capacity.
- Playbook grounding candidate: attaches auditable rule IDs such as `PB-SHELTER-CAPACITY`, `PB-MEDICATION-CONTINUITY`, and `PB-ACCESSIBLE-TRANSPORT` to each triage response.
- Responder packet candidate: creates a copy-ready operational handoff with case priority, playbook IDs, primary official route, missing information, language/access cue, and do-not-promise constraints.
- Household message candidate: creates a plain-English holding note for families while preserving official-channel, callback, and qualified-interpreter boundaries.
- Audit trace candidate: exposes machine-readable risk level, signals, playbook IDs, official routes, blocked claims, and response contract.
- Heatwave/cooling-center routing: adds `PB-HEAT-COOLING-CENTER`, public health heat line checks, no-car transport routing, and medication-storage continuity for heat events.
- Decision brief UI: surfaces review level, playbook count, official-route count, and audit readiness in the first result viewport.
- Structured case export candidate: emits copyable JSON with case fingerprint, review level, playbook IDs, official routes, blocked claims, human-review flag, missing information, and response contract.
- Human review reason candidate: explains why a responder must review a case, then carries that rationale through responder handoff, responder packet, audit trace, and structured export.
- Source verification ledger candidate: quarantines social-media rumors and stale capacity/route claims, then records known, unknown, freshness, and official-channel checks before any public message.
- Kaggle-ready writeup candidate: `docs/final_kaggle_writeup_EXP020.md` is checked for word count, evidence terms, and public links.
- Judging evidence matrix: `docs/judging_evidence_matrix_EXP021.md` maps rubric claims to concrete links, files, screenshots, and commands.
- UI evidence: local Flask/static demo exposes decision brief, playbook grounding, responder packet, household message, audit trace, and heatwave routing; GitHub Pages should be synced before any Kaggle refresh.
- Submission note: EXP-023 has been submitted to Kaggle with the 12-section writeup, 11/11 stress validation, heatwave/cooling-center routing, decision brief, EXP023 bundle, and stale temporary-demo link absent. EXP-028 is a later local candidate with 14/14 stress validation, structured case export, explicit human review reasons, and source verification ledger.

## Gemma 4 Runtime

- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`
- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`
- Status: ready.

## Local Demo

- Screenshot: `outputs\local_validation\local_demo_audit_trace_7867_20260514.png`
- Static package: `outputs\submission_assets\public_demo_static.zip`
- Public code repo: `https://github.com/huier5635-cmd/resilience-copilot-gemma4`
- Public live demo: `https://huier5635-cmd.github.io/resilience-copilot-gemma4/`
- Public demo screenshot: `outputs\local_validation\github_pages_exp026_online_20260516.png`
- Pitch deck: `outputs\submission_assets\resilience_copilot_pitch_v2.pptx`

## Kaggle Draft

- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`
- Final writeup candidate: `docs/final_kaggle_writeup_EXP020.md`
- Checklist: 7/7 complete.
- Submission status: submitted_exp023_heatwave_decision_brief_verified.
- Final submission created: `True`
- Screenshot: `outputs\local_validation\kaggle_exp023_final_verified_top_20260515.png`

## Video

- Local draft: `outputs\submission_assets\resilience_copilot_caption_video_20260513.webm`
- Public YouTube URL: `https://youtu.be/CmqCV8Ic9cY`

## Missing Assets

