# Memory Consolidation Report

## Summary

- Total memories: 53
- Type counts: {'episodic': 19, 'semantic': 20, 'procedural': 7, 'reflective': 7}
- Promoted/protected memories: 27
- Quarantined memories: 0
- Average importance: 0.912

## Consolidation Policy

- Episodic memories are raw validation experiences.
- Semantic memories are promoted only from passing local validation patterns.
- Procedural memories come from the human-reviewed skill library.
- Reflective memories remain review-only and cannot update runtime policy automatically.
- Safety invariants are pinned and cannot be decayed by recency.

## Repeated Topics

- pet rumor shelter: 4 related memories
- pet rumor shelter transport: 5 related memories
- rumor shelter transport: 8 related memories
- transport: 3 related memories

## Forgetting and Decay

- Passed high-risk safety memories are retained.
- Low-importance memories can be summarized after reviewer approval.
- Failed memories are quarantined until a reviewer decides whether to add a new validation case.
- No memory is allowed to weaken emergency-service, diagnosis, capacity, transport, or human-review constraints.
