# Kaggle Gemma 4 Runtime Evidence

- Date: 2026-05-13
- Notebook: `https://www.kaggle.com/code/zhenhuier/notebook5022dfd167/edit`
- Model resource: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`
- Device: Tesla T4
- Python: 3.12.12
- Torch: 2.10.0+cu128
- Transformers: 5.8.0.dev0
- CUDA available: True
- Latency: 18.014 s
- New tokens: 160
- Raw text log: `outputs/local_validation/kaggle_gemma4_evidence_20260513.txt`
- Screenshot: `outputs/local_validation/kaggle_gemma4_evidence_20260513_cdp.png`

## Prompt

System: You are Resilience Copilot. Do not diagnose. Do not invent local shelter capacity. Escalate high-risk cases.

User: A family of five was evacuated after a flood. Two children are cold, grandmother forgot blood pressure medicine, and they need a shelter that accepts pets. Answer with Risk level, Case signals, Action plan, Clarifying questions, Safety boundary.

## Parsed Response Summary

Gemma 4 classified the case as high risk, identified flood evacuation, cold children, missed blood pressure medicine, and pet-compatible shelter need. It recommended immediate triage, contacting official shelter/emergency channels, and medication coordination.

## Evidence Risk Note

The response says to inquire about shelter capacity through official channels. In the final product prompt and safety sidecar, we must keep the stricter wording: do not invent real-time shelter capacity.
