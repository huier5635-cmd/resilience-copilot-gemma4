# Agent Graph Orchestration

## Positioning

This is a LangGraph-compatible bounded multi-agent graph. If `langgraph` is installed, the graph runs through `StateGraph`; otherwise the repository uses a deterministic fallback graph with the same node order and audit trace.

## Nodes

- `planner`
- `coordinator`
- `risk_specialist`
- `memory_retriever`
- `playbook_specialist`
- `tool_router`
- `generation_specialist`
- `safety_contract_checker`
- `summary_agent`

## Safety Boundary

- The graph does not call live external APIs.
- The graph does not call emergency services or book shelters.
- The graph does not change the 16-section response contract.
- The graph can retrieve memory and suggest policy ideas only under human review.

## Latest Report

- Runtime mode: `langgraph_stategraph`
- Demo cases: 3
- Ready: `True`
