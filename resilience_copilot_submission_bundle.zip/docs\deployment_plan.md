# Public Deployment Plan

Current status: the local demo runs, but it is not yet a public live demo.

## Recommended Route

1. Create a public GitHub repository named `resilience-copilot-gemma4`.
2. Upload this project, excluding `data/raw/*.zip`, local browser screenshots that are not needed, and caches.
3. Create a Hugging Face Space using Flask or Gradio.
4. State clearly that the online demo uses the safety sidecar and that official Gemma 4 runtime evidence is in the Kaggle Notebook.
5. If the online demo directly runs Gemma 4, use a deployable model/API path; do not rely on `/kaggle/input/...` outside Kaggle.

## Static Demo Package

For a fast durable deployment, upload the contents of `public_demo/` to any static host.

Prepared zip:

`outputs/submission_assets/public_demo_static.zip`

Verified screenshot:

`outputs/local_validation/public_demo_static_20260513.png`

## Minimum Link Set for Final Submission

- Code repo: public GitHub repository or public Kaggle Notebook.
- Live demo: public Hugging Face Space or public Kaggle Notebook app/demo.
- Model evidence: Kaggle Notebook run log.
- Video: public YouTube video.

## Current Blockers

- No public YouTube video URL yet.
- No public repository URL yet.
- The local machine currently reports no `git` command in PowerShell.
- Current public demo is only a temporary Cloudflare quick tunnel.

## Temporary Live Demo

Temporary URL:

`https://applied-rico-impose-stated.trycloudflare.com`

Status:

- Verified HTTP 200 on 2026-05-13.
- Backed by local Flask process on `127.0.0.1:7861`.
- Tunnel process id: `12936`.
- Log: `outputs/local_validation/cloudflared_7861_stderr.log`.
- Risk: account-less Cloudflare quick tunnels have no uptime guarantee. Replace this with a durable Hugging Face Space, GitHub Pages app, or named Cloudflare tunnel before final judging.

## Kaggle Draft Status

The Kaggle Writeup draft is saved at:

`https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`

The draft is 6/7 complete. Kaggle keeps the final Submit button disabled until a YouTube video is added.
