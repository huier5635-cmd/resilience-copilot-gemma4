# Local Evidence Report

## Gate

- Ready to submit: `False`
- Demo cases: 2 / 2
- Holdout cases: 2 / 2

## Gemma 4 Runtime

- Kaggle evidence notebook template: `notebooks/experiments/kaggle_single_cell_evidence.py`
- Official model path: `/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`
- Status: ready.

## Local Demo

- Screenshot: `outputs\local_validation\local_demo_7861_20260513.png`

## Kaggle Draft

- Writeup URL: `https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`
- Checklist: 6/7 complete.
- Submit test: blocked by missing YouTube video; no final submission was created.
- Screenshot: `outputs\local_validation\kaggle_writeup_draft_latest_20260513.png`

## Missing Assets

- public_video_url: missing
- public_code_repo_url: missing
- public_live_demo_url: missing
