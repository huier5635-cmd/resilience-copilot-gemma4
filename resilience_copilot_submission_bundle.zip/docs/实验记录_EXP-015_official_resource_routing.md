# EXP-015 Official Resource Routing

## 假设

救灾 triage 的关键风险不只是“给建议慢”，而是“把未经核验的资源当成事实”。如果 sidecar 能把 shelter、medical、transport、animal services、interpreter、utility 和 emergency needs 拆成官方核验点，就能提高安全性和评审里的技术可信度。

## 改动内容

- `scripts/resilience_copilot_baseline.py` 新增 `Official resource checks` 输出区块。
- Flask API 新增 `official_resource_checks` 字段。
- 本地 demo 与 GitHub Pages 静态 demo 新增 Resource routing 样例和结果区块。
- `data/cases/stress_cases.jsonl` 从 5 条扩展到 6 条，新增官方资源路由 case。
- README、writeup 草稿、学习台账、本地验证手册、manifest 和 evidence report 同步更新。
- Pitch deck 已更新到 6/6 stress validation，并展示 official-resource-routing 路径。

## 本地验证命令

```powershell
python scripts\evaluate_demo_cases.py --cases data\cases\stress_cases.jsonl --output outputs\local_validation\stress_eval.json
python scripts\run_local_validation.py
python scripts\generate_evidence_report.py
python scripts\build_submission_bundle.py
python scripts\check_submission_assets.py
```

UI 级验证：

```powershell
# Flask demo: 打开 http://127.0.0.1:7863 并点击 Resource routing 样例
# Static demo: 打开 public_demo/index.html 并点击 Resource routing 样例
# GitHub Pages: 打开公开 demo 并点击 Resource routing 样例
```

## 本地分数

- demo cases: 2/2
- holdout cases: 2/2
- stress cases: 6/6
- `ready_to_submit=true`
- submission assets: `all_ready=true`

## 是否提交 Kaggle

待本地验证、PPT、bundle 和公开 GitHub Pages 验证通过后再更新 Kaggle。不会直接提交未验证版本。

## Public score / rank

- public score: N/A
- leaderboard rank: N/A

原因：本赛题是 Kaggle Writeup / hackathon 评审，不是带 public leaderboard 的 CSV 竞赛。

## 失败或成功原因

当前分支的脚本 gate 已过：demo 2/2、holdout 2/2、stress 6/6、`ready_to_submit=true`。Flask demo 与 static demo 已通过 Resource routing UI 验证。下一步要验证公开 GitHub Pages、PPT 和提交包是否完全一致，防止材料里残留 5/5 或 seven-section 表述。
