# PPT 与证据链

通俗解释：比赛作品不是只靠代码赢。评委通常先看到故事、截图、视频和链接，再决定要不要深入看实现。PPT 的作用是把“我们解决了什么问题、怎么保证安全、有哪些证据能查”在几分钟内讲清楚。

专业术语：pitch deck、evidence chain、judge-facing narrative、artifact packaging、reproducibility.

这次学到的点：

- `pitch deck` 不是论文，也不是 README 的截图版；每页只做一个任务。
- 证据链要从本地验证连到公开资产：local validation -> demo screenshot -> Kaggle runtime evidence -> public repo/live demo/video。
- 可编辑 PPTX 比纯截图更好，因为后面可以继续改文字、替换图表、追加链接。
- 提交包要脚本化生成，否则新增资产后很容易忘记放进 zip。

下一步应该学：

1. 如何把技术项目压缩成 5 分钟路演故事。
2. 如何用一张图解释模型 guardrail / sidecar 架构。
3. 如何给评委准备“可核查证据”，而不是只写宣传语。
