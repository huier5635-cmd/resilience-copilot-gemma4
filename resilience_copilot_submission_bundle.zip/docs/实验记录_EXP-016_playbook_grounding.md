# EXP-016 Auditable Playbook Grounding

## 假设

评委不仅要看到“答案安全”，还要看到系统为什么安全。给每次 triage 输出附上可审计的 playbook rule ID，可以提高技术深度、可复现性和一线使用可信度。

## 改动内容

- `knowledge_base/emergency_playbook.json` 新增 `playbook_rules` schema。
- `scripts/resilience_copilot_baseline.py` 新增 `Playbook references` 输出区块。
- `Responder handoff` 新增 `Playbook basis`，保留可复制的规则依据。
- Flask API 新增 `playbook_references` 字段。
- Flask demo 与 static demo 新增 `Playbook References` 面板。
- 风险检测从“命中 high 后提前返回”改为“收集全部信号，再取最高风险等级”，避免遗漏 pet、transport、shelter 等并发需求。
- `data/cases/stress_cases.jsonl` 从 6 条扩展到 7 条，新增多需求 playbook grounding case。

## 本地验证命令

```powershell
python scripts\evaluate_demo_cases.py --cases data\cases\stress_cases.jsonl --output outputs\local_validation\stress_eval.json
python scripts\run_local_validation.py
python scripts\generate_evidence_report.py
python scripts\build_submission_bundle.py
python scripts\check_submission_assets.py
```

UI 级验证：

```powershell
# Flask demo: 打开 http://127.0.0.1:7864，输入 playbook grounding stress case
# Static demo: 打开 public_demo/index.html，输入同一 stress case
```

## 本地分数

- demo cases: 2/2
- holdout cases: 2/2
- stress cases: 7/7
- `ready_to_submit=true`
- UI checks: Flask / static 均通过

## 是否提交 Kaggle

否。今天已经进行了 2 次 Kaggle 正式更新；EXP-016 作为明天的可提交原创候选分支保留，避免浪费每日提交机会。

## Public score / rank

- public score: N/A
- leaderboard rank: N/A

原因：本赛题是 Kaggle Writeup / hackathon 评审，不是带 public leaderboard 的 CSV 竞赛。

## 失败或成功原因

成功。新增 playbook grounding 没有破坏已有 demo / holdout / stress gate，并修复了高风险提前返回导致并发需求信号丢失的问题。这个分支适合作为下一轮提交主题：从“安全 sidecar”升级为“可审计的 responder playbook 系统”。
