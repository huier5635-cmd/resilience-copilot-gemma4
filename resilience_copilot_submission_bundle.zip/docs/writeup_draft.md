# Resilience Copilot: Safety-First Disaster Relief Triage with Gemma 4

Resilience Copilot is a disaster-relief triage assistant for messy evacuation cases where a family may need shelter, medication continuity, transport, pet accommodation, language access, and responder handoff at the same time.

The problem is not only speed. During floods, heatwaves, power outages, and evacuations, a generic chatbot can sound confident while missing risk signals or inventing real-time shelter capacity. That is dangerous. Our design goal is to make Gemma 4 useful in crisis workflows while keeping operational safety boundaries visible.

## What It Does

The prototype takes a short case note and returns seven sections:

1. Risk level.
2. Case signals.
3. Action plan.
4. Clarifying questions.
5. Language support.
6. Responder handoff.
7. Safety boundary.

For example, when a family of five is evacuated after a flood, two children are cold, a grandmother forgot blood pressure medication, and the family needs a pet-compatible shelter, the system marks the case high risk. It surfaces child cold exposure, medication interruption, and pet shelter constraints, then creates a responder handoff plan.

The intended users are community volunteers, shelter coordinators, and small emergency-response teams who need structured triage notes rather than polished but unsafe advice. The assistant does not replace emergency services. It reduces friction by converting incomplete case notes into safer next actions and clearer questions for human responders.

## Technical Design

The original contribution is a lightweight safety sidecar around generation. Before the response layer runs, the sidecar detects high-risk signals such as children, older adults, pregnancy, insulin continuity, oxygen equipment, medication interruption, electrical hazards, floodwater, dialysis continuity, transport barriers, language access, and unverified shelter-capacity rumors.

Those signals become explicit constraints for the response: do not diagnose, do not invent local shelter capacity, and escalate immediate danger to official responders. The latest sidecar also creates language-access instructions and a compact responder handoff note, so a volunteer can copy the operational summary without burying critical facts in prose. The public demo exposes this control path directly so judges can inspect the safety behavior without relying on a hidden model call.

Gemma 4 evidence was captured in Kaggle Notebook using the official model resource:

`/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`

The notebook logs Python 3.12.12, Torch 2.10.0+cu128, Transformers 5.8.0.dev0, CUDA on Tesla T4, prompt, response, latency, and generated token count. One recorded run produced 160 new tokens with 18.014 seconds latency. The intended production pattern is Gemma 4 for language generation, with the sidecar acting as a pre-generation risk detector and post-generation safety contract.

## Validation

Because this hackathon has no provided training dataset, local validation is scenario-based rather than CSV leaderboard-based. I split cases into three groups:

- Demo cases: presentation examples that can appear in the video.
- Holdout cases: safety checks not baked into prompts.
- Stress cases: edge cases that often break generic assistants.

Current local validation passes 2/2 demo cases, 2/2 holdout cases, and 5/5 stress cases. The stress set covers pregnancy plus insulin continuity, oxygen concentrator power loss, Spanish and Cantonese language-access barriers, medication needs, and social-media rumors about shelter capacity. These are small tests, but they force the project to prove the exact claims made in the writeup: risk detection, official-channel routing, no diagnosis, no invented capacity, and usable language-aware handoff.

## Why It Matters

A volunteer can paste a rough note like: "Older adult uses oxygen, power is out, backup battery almost empty, family asks whether to wait until morning." The assistant should not give casual reassurance. It should escalate the oxygen/powered-medical-device risk, ask for location and callback number, and route through emergency, utility medical-priority, or clinical support channels.

That is the core value: not replacing responders, but making the handoff note safer, faster, and less dependent on the volunteer knowing every risk rule under pressure.

## Evidence And Links

Public demo: `https://huier5635-cmd.github.io/resilience-copilot-gemma4/`

Public code: `https://github.com/huier5635-cmd/resilience-copilot-gemma4`

Video: `https://youtu.be/CmqCV8Ic9cY`

The code repository includes the static demo, validation scripts, scenario cases, experiment log, learning log, pitch deck, and submission bundle. The editable pitch deck is also published as a root-level repository asset: `resilience_copilot_pitch_v2.pptx`. The Kaggle Notebook linked in the project resources provides the official Gemma 4 runtime evidence.

## Next Steps

The next useful version would connect official local shelter feeds, responder-approved playbooks, and richer multilingual intake forms. I would also add a Gemma 4 generation endpoint behind the same sidecar so that every model answer is checked against the risk signals and safety contract before a volunteer sees it.
