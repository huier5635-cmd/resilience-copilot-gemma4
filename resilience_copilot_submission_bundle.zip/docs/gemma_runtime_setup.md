# Gemma 4 运行证据方案

## 推荐路线：Kaggle Notebook

证据效力最高，因为 Kaggle Notebook 可以直接挂载官方模型资源，并在 Writeup 中引用 notebook。

已确认模型资源路径：

```text
/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1
```

Kaggle 操作：

1. New Notebook。
2. 右侧 Add Input / Add Models。
3. 搜索 `Gemma 4`。
4. 选择 `Google Gemma 4`、Framework `Transformers`、variation `gemma-4-e2b-it`。
5. 打开 GPU，优先 T4 x2。
6. 运行 `notebooks/experiments/kaggle_single_cell_evidence.py` 的内容。

## 已知坑

Kaggle 默认环境可能出现：

```text
ValueError: The checkpoint you are trying to load has model type `gemma4`
```

解决方式：升级 transformers 后，在新的 Python 子进程中加载模型，避免当前 notebook 内核缓存旧映射。

## 本地 Ollama 路线

用途：Live Demo 录屏时展示本地接口。

当前状态：

- `ollama` 命令若不可用，先不把它作为主证据。
- 如果后续安装成功，再运行 `ollama pull gemma4` 或官方 tag。
- 运行后用 `ollama ps` 和 `/api/generate` JSON 响应作为辅助证据。

## 写入 Writeup 的证据点

- Kaggle GPU 型号。
- Gemma 4 模型路径。
- transformers / torch 版本。
- prompt、response、latency、new tokens。
- 说明没有诊断、没有编造 shelter capacity，并对高风险 case 做升级。

## 本次重试结果

- 状态：成功。
- Notebook：`https://www.kaggle.com/code/zhenhuier/notebook5022dfd167/edit`
- 设备：Tesla T4。
- 版本：Python 3.12.12、Torch 2.10.0+cu128、Transformers 5.8.0.dev0。
- 延迟：18.014 s。
- 生成 token：160。
- 本地证据：`outputs/local_validation/kaggle_gemma4_evidence_20260513.md`。
