# EXP-012 Pitch deck polish and submission bundle refresh

- 日期：2026-05-14
- 假设：评委在短时间内需要快速看懂项目价值；一份可编辑、视觉更强的 pitch deck 能增强故事表达和证据链，但不应该替代本地验证。
- 改动：新增 8 页 `Resilience Copilot` pitch deck，包含问题、sidecar 机制、公开 demo、stress validation、Kaggle Gemma 4 Notebook 证据和公开链接；新增 `scripts/build_submission_bundle.py`，把 PPT 纳入提交 bundle；更新 manifest、README、writeup draft 和 evidence report。
- 本地验证命令：`python scripts\build_submission_bundle.py`; `python scripts\run_local_validation.py`; `python scripts\generate_evidence_report.py`
- 本地分数：demo 2/2，holdout 2/2，stress 4/4，`ready_to_submit=true`，submission assets all ready。
- 是否提交 Kaggle：否，本轮先刷新证据资产，不消耗 Kaggle 提交机会。
- Public score：不适用。
- Leaderboard rank：不适用。
- 结论：PPT 已进入 `outputs/submission_assets/resilience_copilot_pitch_v2.pptx`，刷新后的 bundle 为 `outputs/submission_assets/resilience_copilot_submission_bundle.zip`。
