# EXP-013 Submission Refresh

## 改动内容

- 更新 Kaggle Writeup 正文，明确写入 `pitch deck` 和 `resilience_copilot_pitch_v2.pptx`。
- 更新公开 GitHub 仓库根目录：
  - `README.md`
  - `resilience_copilot_pitch_v2.pptx`
  - `resilience_copilot_submission_bundle.zip`
- 修正 README 的公开展示结构，避免评委第一屏看到编码异常或证据缺口。

## 本地验证命令

```powershell
python scripts\build_submission_bundle.py
python scripts\check_submission_assets.py
```

## 本地分数

- `all_ready=true`
- demo cases: 2/2
- holdout cases: 2/2
- stress cases: 4/4
- Kaggle checklist: 7/7

## 是否提交 Kaggle

是。2026-05-14 更新已提交的 Kaggle Writeup 正文；不是 leaderboard 型提交。

## Public score / rank

- public score: N/A
- leaderboard rank: N/A

原因：The Gemma 4 Good Hackathon 以 Writeup 和项目材料评审为主，不是带 public leaderboard 的 CSV 竞赛。

## 结果与复盘

成功。Kaggle 页面刷新后确认仍为 `Submitted!`，且正文包含 `4/4 stress cases`、`pitch deck`、`resilience_copilot_pitch_v2.pptx` 和 `submission bundle`。

下一步不要继续大幅改方向；如果还有提交机会，应优先用于小而可证的原创增强，例如多语言 intake、官方资源链接占位、或更清晰的 responder handoff 模板。
