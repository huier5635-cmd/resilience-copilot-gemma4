# Public Deployment Plan

Current status: the local demo runs, and a durable GitHub Pages static demo is now live.

## Recommended Route

1. Keep the public GitHub repository `resilience-copilot-gemma4` as the code evidence.
2. Use GitHub Pages as the durable static demo for the Kaggle writeup.
3. Optional upgrade: create a Hugging Face Space using Flask or Gradio if we want a server-backed interactive demo.
4. State clearly that the online demo uses the safety sidecar and that official Gemma 4 runtime evidence is in the Kaggle Notebook.
5. If the online demo directly runs Gemma 4, use a deployable model/API path; do not rely on `/kaggle/input/...` outside Kaggle.

## Static Demo Package

For a fast durable deployment, upload the contents of `public_demo/` to any static host.

Prepared zip:

`outputs/submission_assets/public_demo_static.zip`

Verified screenshot:

`outputs/local_validation/public_demo_static_20260513.png`

## Minimum Link Set for Final Submission

- Code repo: `https://github.com/huier5635-cmd/resilience-copilot-gemma4`.
- Live demo: `https://huier5635-cmd.github.io/resilience-copilot-gemma4/`.
- Model evidence: Kaggle Notebook run log.
- Video: public YouTube video.

## Current Blockers

- No public YouTube video URL yet.
- The local machine currently reports no `git` command in PowerShell.
- Optional: upgrade from static demo to server-backed Hugging Face Space.

## Temporary Live Demo

Temporary URL:

`https://applied-rico-impose-stated.trycloudflare.com`

Status:

- Verified HTTP 200 on 2026-05-13.
- Backed by local Flask process on `127.0.0.1:7861`.
- Tunnel process id: `12936`.
- Log: `outputs/local_validation/cloudflared_7861_stderr.log`.
- Risk: account-less Cloudflare quick tunnels have no uptime guarantee. Replace this with a durable Hugging Face Space, GitHub Pages app, or named Cloudflare tunnel before final judging.

## Durable GitHub Pages Demo

Public demo URL:

`https://huier5635-cmd.github.io/resilience-copilot-gemma4/`

Public code repo:

`https://github.com/huier5635-cmd/resilience-copilot-gemma4`

Status:

- GitHub repo is public.
- GitHub Pages is enabled from the `main` branch root.
- Verified HTTP 200 and page title `Resilience Copilot` on 2026-05-13.
- Added to the Kaggle draft project links on 2026-05-13.

## Kaggle Draft Status

The Kaggle Writeup draft is saved at:

`https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423`

The draft is 6/7 complete. Kaggle keeps the final Submit button disabled until a YouTube video is added.
