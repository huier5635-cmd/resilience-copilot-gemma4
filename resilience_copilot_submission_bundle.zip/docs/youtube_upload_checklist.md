# YouTube Upload Checklist

Local video draft:

`outputs/submission_assets/resilience_copilot_caption_video_20260513.webm`

Metadata:

`outputs/submission_assets/youtube_title_and_description.txt`

## Upload Settings

- Visibility: Public or Unlisted.
- Audience: Not made for kids.
- Category: Science & Technology or Nonprofits & Activism.
- License: Standard YouTube License.
- Comments: optional.

## After Upload

1. Copy the YouTube URL.
2. Add it to Kaggle Writeup media gallery as a video link.
3. Update `configs/submission_manifest.json`:
   - `public_video_url.status = "ready"`
   - `public_video_url.url = "<YouTube URL>"`
4. Re-run:

```powershell
python scripts\run_local_validation.py
python scripts\generate_evidence_report.py
```

5. Confirm Kaggle checklist becomes 7/7 before final Submit.

## Current Blocker

- 2026-05-13: Blocker cleared after user confirmation.
- Video URL: `https://youtu.be/CmqCV8Ic9cY`.
- Visibility: Unlisted.
- Kaggle checklist: 7/7 complete after adding the video to Media Gallery.
