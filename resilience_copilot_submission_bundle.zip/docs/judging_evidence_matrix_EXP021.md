# EXP-021 Judging Evidence Matrix

Purpose: make the final Kaggle submission easy to review under deadline pressure. Each claim below points to a concrete asset, link, command, or validation result.

## Judge-Facing Links

| Evidence | Link |
| --- | --- |
| Kaggle writeup | https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423 |
| Public demo | https://huier5635-cmd.github.io/resilience-copilot-gemma4/ |
| Public code | https://github.com/huier5635-cmd/resilience-copilot-gemma4 |
| Video | https://youtu.be/CmqCV8Ic9cY |
| Kaggle Gemma 4 evidence notebook | https://www.kaggle.com/code/zhenhuier/notebook5022dfd167 |

## Rubric Map

| Rubric area | What the judge should see | Primary evidence | Backup evidence |
| --- | --- | --- | --- |
| Impact and vision | Disaster volunteers need safer triage for evacuation, medication, shelter, pets, language access, and official handoff. | `docs/final_kaggle_writeup_EXP020.md`; video; pitch deck | `README.md`; public demo |
| Technical depth | A sidecar detects risk signals, explains the human review reason, adds playbook IDs, blocks unsafe claims, routes official resource checks, and creates responder/household outputs. | `scripts/resilience_copilot_baseline.py`; `public_demo/`; `app/` | `outputs/local_validation/evidence_report.md` |
| Gemma 4 runtime evidence | Official Kaggle model resource is mounted and inference evidence is logged. | `outputs/local_validation/kaggle_gemma4_evidence_20260513.md`; Kaggle notebook link | `notebooks/experiments/kaggle_single_cell_evidence.py` |
| Validation | Scenario validation passes demo, holdout, stress, writeup readiness, and judging packet checks. | `outputs/local_validation/local_validation_report.json`; `outputs/local_validation/evidence_report.md` | `data/cases/*.jsonl` |
| Original branch | The original improvements are safety sidecar, official routing, language access, playbook grounding, responder packet, household message, audit trace, structured export, and human review reason. | `scripts/resilience_copilot_baseline.py`; `data/cases/stress_cases.jsonl`; public demo | `outputs/local_validation/stress_eval.json` |
| Storytelling | The project is understandable in a short video and editable pitch deck, not just code. | `outputs/submission_assets/resilience_copilot_pitch_v2.pptx`; YouTube link | public demo |
| Reproducibility | Public repo, static demo package, evidence bundle, and scripts are included. | `outputs/submission_assets/resilience_copilot_submission_bundle.zip`; GitHub link | `outputs/submission_assets/public_demo_static.zip` |

## Final Submission Slot Plan

1. First next submission slot: paste `docs/final_kaggle_writeup_EXP020.md` into Kaggle, then verify all public links.
2. Attach or reference the latest bundle: `outputs/submission_assets/resilience_copilot_submission_bundle.zip`.
3. Confirm the public demo still opens and the video link is visible.
4. Capture a screenshot of the submitted page and update `configs/submission_manifest.json`.
5. Use a second slot only if a visible link, screenshot, or wording error is found.
6. Keep at least one original branch ready: EXP-019 audit trace plus EXP-020 writeup readiness. Do not spend all remaining slots on public reproduction.

## What Not To Overclaim

- Do not claim live shelter capacity.
- Do not claim medical diagnosis or treatment.
- Do not claim road, transport, or utility availability is current unless verified through official local channels.
- Do not claim the household message is a complete translation for safety-critical details; qualified interpreters are required.
- Do not claim the small validation set proves field deployment readiness. It proves targeted safety gates for the hackathon prototype.
# EXP-024 Addendum

- Technical depth update: the current local/public-demo candidate adds structured case export JSON with `case_fingerprint`, `review_level`, `playbook_ids`, `official_routes`, `blocked_claims`, `required_human_review`, and `response_contract`.
- Validation update: stress validation is now 12/12 locally; EXP-024 adds `stress_structured_case_export_reviewable`.
- Evidence files: `outputs/local_validation/public_demo_exp024_runtime_check_20260515.json`, `public_demo_exp024_desktop_20260515.png`, and `public_demo_exp024_mobile_20260515.png`.
- Submission status: EXP-024 is not yet submitted to Kaggle; EXP-023 remains the latest submitted Kaggle version.

# EXP-026 Addendum

- Technical depth update: the current local candidate adds `Human review reason` to the response, audit trace, responder handoff, responder packet, and structured case export. This makes the human-in-the-loop contract easier to inspect.
- Validation update: stress validation is now 13/13 locally; EXP-026 adds `stress_human_review_reason_multifactor`.
- Evidence files: `outputs/local_validation/public_demo_exp026_runtime_check_20260516.json`, `public_demo_exp026_desktop_20260516.png`, and `public_demo_exp026_mobile_20260516.png`.
- Submission status: EXP-026 is not yet submitted to Kaggle; EXP-023 remains the latest submitted Kaggle version until the next refresh.
