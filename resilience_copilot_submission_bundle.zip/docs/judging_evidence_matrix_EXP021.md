# EXP-021 Judging Evidence Matrix

Purpose: make the final Kaggle submission easy to review under deadline pressure. Each claim below points to a concrete asset, link, command, or validation result.

## Judge-Facing Links

| Evidence | Link |
| --- | --- |
| Kaggle writeup | https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423 |
| Public demo | https://huier5635-cmd.github.io/resilience-copilot-gemma4/ |
| Public code | https://github.com/huier5635-cmd/resilience-copilot-gemma4 |
| Video | https://youtu.be/CmqCV8Ic9cY |
| Kaggle Gemma 4 evidence notebook | https://www.kaggle.com/code/zhenhuier/notebook5022dfd167 |

## Rubric Map

| Rubric area | What the judge should see | Primary evidence | Backup evidence |
| --- | --- | --- | --- |
| Impact and vision | Disaster volunteers need safer triage for evacuation, medication, shelter, pets, language access, and official handoff. | `docs/final_kaggle_writeup_EXP020.md`; video; pitch deck | `README.md`; `docs/writeup_draft.md` |
| Technical depth | A sidecar detects risk signals, adds playbook IDs, blocks unsafe claims, routes official resource checks, and creates responder/household outputs. | `scripts/resilience_copilot_baseline.py`; `public_demo/`; `app/` | `docs/本地验证冲分手册.md` |
| Gemma 4 runtime evidence | Official Kaggle model resource is mounted and inference evidence is logged. | `outputs/local_validation/kaggle_gemma4_evidence_20260513.md`; Kaggle notebook link | `notebooks/experiments/kaggle_single_cell_evidence.py` |
| Validation | Scenario validation passes demo, holdout, stress, writeup readiness, and judging packet checks. | `outputs/local_validation/local_validation_report.json`; `outputs/local_validation/evidence_report.md` | `data/cases/*.jsonl` |
| Original branch | The original improvements are safety sidecar, official routing, language access, playbook grounding, responder packet, household message, and audit trace. | `docs/实验记录_EXP-019_audit_trace.md`; `docs/实验记录_EXP-020_writeup_readiness.md` | `docs/实验记录.md` |
| Storytelling | The project is understandable in a short video and editable pitch deck, not just code. | `outputs/submission_assets/resilience_copilot_pitch_v2.pptx`; YouTube link | `docs/youtube_upload_checklist.md` |
| Reproducibility | Public repo, static demo package, evidence bundle, and scripts are included. | `outputs/submission_assets/resilience_copilot_submission_bundle.zip`; GitHub link | `outputs/submission_assets/public_demo_static.zip` |

## Final Submission Slot Plan

1. First next submission slot: paste `docs/final_kaggle_writeup_EXP020.md` into Kaggle, then verify all public links.
2. Attach or reference the latest bundle: `outputs/submission_assets/resilience_copilot_submission_bundle.zip`.
3. Confirm the public demo still opens and the video link is visible.
4. Capture a screenshot of the submitted page and update `configs/submission_manifest.json`.
5. Use a second slot only if a visible link, screenshot, or wording error is found.
6. Keep at least one original branch ready: EXP-019 audit trace plus EXP-020 writeup readiness. Do not spend all remaining slots on public reproduction.

## What Not To Overclaim

- Do not claim live shelter capacity.
- Do not claim medical diagnosis or treatment.
- Do not claim road, transport, or utility availability is current unless verified through official local channels.
- Do not claim the household message is a complete translation for safety-critical details; qualified interpreters are required.
- Do not claim the small validation set proves field deployment readiness. It proves targeted safety gates for the hackathon prototype.
