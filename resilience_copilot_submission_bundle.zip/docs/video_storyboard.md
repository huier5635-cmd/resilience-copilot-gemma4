# Video Storyboard

Limit: Kaggle requires a public YouTube video. Keep it under 3 minutes.

## 0:00 - 0:20 Problem

Show the flood evacuation case. Explain that disaster volunteers need fast triage for shelter, medication continuity, pets, transport, and safe escalation.

## 0:20 - 0:55 Product Demo

Open `http://127.0.0.1:7861` and run the family flood case. Show risk level, case signals, action plan, clarifying questions, and safety boundary.

## 0:55 - 1:30 Safety Sidecar

Show the playbook and holdout validation. Explain the original contribution: a lightweight safety sidecar catches children, older adults, medication interruption, electrical hazards, floodwater, dialysis continuity, and transport barriers before generation.

## 1:30 - 2:10 Gemma 4 Evidence

Show the Kaggle Notebook evidence: official Gemma 4 model resource, Tesla T4, model path, versions, latency, and generated tokens.

## 2:10 - 2:40 Impact

Show a responder handoff note. Emphasize that the assistant does not replace emergency services; it reduces triage friction and makes handoffs safer.

## 2:40 - 2:55 Next Step

Show the deployment checklist: official shelter feeds, responder-approved playbooks, and public live demo deployment.

## Assets

- Local demo: `http://127.0.0.1:7861`
- Temporary public demo: `https://applied-rico-impose-stated.trycloudflare.com`
- Local screenshot: `outputs/local_validation/local_demo_7861_20260513.png`
- Upgraded local screenshot: `outputs/local_validation/local_demo_upgraded_7861_20260513.png`
- Gemma 4 evidence: `outputs/local_validation/kaggle_gemma4_evidence_20260513.md`
- Cover image: `outputs/submission_assets/cover_resilience_copilot_560x280.png`
- Caption video draft: `outputs/submission_assets/resilience_copilot_caption_video_20260513.webm`

## Upload Note

The current WebM is a caption-first draft. It can satisfy a YouTube upload test, but a prize-oriented final video should add spoken narration or a cleaner screen recording before the deadline.
