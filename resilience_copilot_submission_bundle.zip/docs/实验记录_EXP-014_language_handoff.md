# EXP-014 Language Access And Responder Handoff

## 假设

救灾场景里的“语言不通”不是普通 UX 问题，而是安全问题。给系统加上 language access 和 responder handoff，可以提高 Impact Track 的实用性，也能作为一个原创小分支被本地验证。

## 改动内容

- `scripts/resilience_copilot_baseline.py` 新增：
  - preferred language detection
  - `Language support`
  - `Responder handoff`
- Flask API 新增 `language_support` 和 `responder_handoff` 字段。
- 本地 demo 与 GitHub Pages 静态 demo 新增 Language access 样例和两个结果区块。
- `data/cases/stress_cases.jsonl` 从 4 条扩展到 5 条，并加强 Spanish/Cantonese language-access 检查。
- 学习台账和本地验证手册补充 language access / handoff 说明。
- Pitch deck 更新到 5/5 stress validation，并使用 language-aware handoff demo 截图。

## 本地验证命令

```powershell
python scripts\evaluate_demo_cases.py --cases data\cases\stress_cases.jsonl --output outputs\local_validation\stress_eval.json
python scripts\run_local_validation.py
python scripts\generate_evidence_report.py
python scripts\build_submission_bundle.py
python scripts\check_submission_assets.py
```

UI 级验证：

```powershell
# Flask demo: 打开 http://127.0.0.1:7862 并点击 Language access 样例
# Static demo: 打开 public_demo/index.html 并点击 Language access 样例
```

## 本地分数

- demo cases: 2/2
- holdout cases: 2/2
- stress cases: 5/5
- `ready_to_submit=true`
- submission assets: `all_ready=true`

## 是否提交 Kaggle

是。2026-05-14 已更新 Kaggle Writeup 正文，并覆盖最终 `resilience_copilot_submission_bundle.zip` 与 `resilience_copilot_pitch_v2.pptx` 附件。

## Public score / rank

- public score: N/A
- leaderboard rank: N/A

原因：本赛题是 Kaggle Writeup / hackathon 评审，不是带 public leaderboard 的 CSV 竞赛。

## 失败或成功原因

成功。新增能力没有破坏原有 demo / holdout / stress gate，并把“语言可及性”从一句愿景变成了可测试输出。Kaggle 页面刷新后确认仍为 `Submitted!`，且正文包含 seven sections、5/5 stress cases、language support、responder handoff、PPT 和 bundle。

下一步：若继续优化，优先做官方资源占位和 responder-approved playbook schema，不要大改产品方向。
