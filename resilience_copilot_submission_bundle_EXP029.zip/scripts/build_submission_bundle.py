"""Build the strict EXP-029 judge-facing evidence bundle."""

from __future__ import annotations

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "submission_assets" / "resilience_copilot_submission_bundle.zip"
CACHE_DIR_NAME = "__" + "pycache__"


INCLUDE_FILES = [
    "README.md",
    "requirements.txt",
    "requirements-agent-optional.txt",
    "resilience_copilot_demo_preview.png",
    "resilience_copilot_github_qr.png",
    "resilience_copilot_demo_qr.png",
    "configs/submission_manifest.json",
    "docs/final_kaggle_writeup_EXP020.md",
    "docs/judging_evidence_matrix_EXP021.md",
    "data/cases/demo_cases.jsonl",
    "data/cases/holdout_cases.jsonl",
    "data/cases/stress_cases.jsonl",
    "data/raw/NOTE.md",
    "outputs/local_validation/evidence_report.md",
    "outputs/local_validation/final_public_release_audit_EXP029_20260518.json",
    "outputs/local_validation/local_validation_report.json",
    "outputs/local_validation/writeup_readiness.json",
    "outputs/local_validation/judging_packet.json",
    "outputs/local_validation/demo_eval.json",
    "outputs/local_validation/holdout_eval.json",
    "outputs/local_validation/stress_eval.json",
    "outputs/local_validation/agentic_learning_report.json",
    "outputs/local_validation/experience_ledger.jsonl",
    "outputs/local_validation/validation_feedback_memory.json",
    "outputs/local_validation/strategy_reflection.md",
    "outputs/local_validation/tool_calling_sandbox_demo.json",
    "outputs/local_validation/voyager_style_learning_loop.json",
    "outputs/local_validation/memory_system_report.json",
    "outputs/local_validation/agent_memory_store.json",
    "outputs/local_validation/memory_retrieval_index.json",
    "outputs/local_validation/memory_retrieval_demo.json",
    "outputs/local_validation/memory_consolidation_report.md",
    "outputs/local_validation/memory_safety_policy.json",
    "outputs/local_validation/agent_graph_orchestration_report.json",
    "outputs/local_validation/agent_graph_trace_demo.json",
    "outputs/local_validation/agent_graph_architecture.md",
    "outputs/local_validation/kaggle_gemma4_evidence_20260513.md",
    "outputs/local_validation/kaggle_exp029_final_verification_20260517.json",
    "outputs/local_validation/kaggle_exp029_final_verified_20260517.png",
    "outputs/local_validation/kaggle_exp029_final_verified_files_20260517.png",
    "outputs/local_validation/public_demo_exp029_desktop_20260517.png",
    "outputs/local_validation/public_demo_exp029_mobile_20260517.png",
    "outputs/local_validation/github_pages_exp029_final_polish_online_check_20260517.json",
    "outputs/local_validation/github_pages_exp029_final_polish_online_desktop_20260517.png",
    "outputs/local_validation/github_pages_exp029_final_polish_online_mobile_20260517.png",
    "outputs/local_validation/github_pages_exp029_final_polish_online_mobile_metrics_20260517.json",
    "outputs/local_validation/public_demo_exp029_reviewer_strip_desktop_20260518.png",
    "outputs/local_validation/public_demo_exp029_reviewer_strip_metrics_20260518.json",
    "outputs/local_validation/stress_eval_exp029.json",
    "outputs/submission_assets/cover_resilience_copilot_560x280.png",
    "outputs/submission_assets/public_demo_static.zip",
    "outputs/submission_assets/resilience_copilot_pitch_v2.pptx",
    "notebooks/experiments/kaggle_single_cell_evidence.py",
    "notebooks/public_reproduction/review_summary_EXP029.md",
    "scripts/build_submission_bundle.py",
    "scripts/check_judging_packet.py",
    "scripts/check_submission_assets.py",
    "scripts/check_writeup_readiness.py",
    "scripts/evaluate_demo_cases.py",
    "scripts/agentic_learning_loop.py",
    "scripts/agent_memory_system.py",
    "scripts/agent_graph_orchestrator.py",
    "scripts/resilience_copilot_baseline.py",
    "scripts/run_local_validation.py",
]

INCLUDE_DIRS = [
    "app",
    "public_demo",
    "knowledge_base",
]


def add_file(zip_file: ZipFile, relative_path: str) -> None:
    path = ROOT / relative_path
    if path.exists() and path.is_file():
        zip_file.write(path, relative_path)


def add_dir(zip_file: ZipFile, relative_dir: str) -> None:
    base = ROOT / relative_dir
    if not base.exists():
        return
    for path in sorted(base.rglob("*")):
        if path.is_file() and CACHE_DIR_NAME not in path.parts:
            zip_file.write(path, str(path.relative_to(ROOT)))


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUT, "w", compression=ZIP_DEFLATED) as zip_file:
        for relative_path in INCLUDE_FILES:
            add_file(zip_file, relative_path)
        for relative_dir in INCLUDE_DIRS:
            add_dir(zip_file, relative_dir)
    print(str(OUT))


if __name__ == "__main__":
    main()
