# Resilience Copilot: Safety-First Disaster Relief Triage with Gemma 4

Resilience Copilot is a crisis-relief triage assistant for messy evacuation and heat-response cases. A single family may need shelter, medication continuity, transport, pet accommodation, cooling-center routing, language access, and responder handoff at the same time. In that setting, a fluent but overconfident chatbot is risky: it may miss oxygen, insulin, cold exposure, heat illness, or language-access signals, or invent real-time shelter or cooling-center capacity.

The goal of this project is to make Gemma 4 useful in a disaster workflow while keeping safety boundaries visible, auditable, and easy for human responders to override.

## What It Does

The prototype takes a short case note and returns a sixteen-section response:

1. Risk level
2. Case signals
3. Human review reason
4. Playbook references
5. Action plan
6. Official resource checks
7. Source verification ledger
8. Transfer brief
9. Clarifying questions
10. Language support
11. Responder handoff
12. Responder packet
13. Household message
14. Audit trace
15. Structured case export
16. Safety boundary

For example, if a volunteer enters: "An older adult uses oxygen, the power is out, the backup battery is almost empty, and the family asks whether to wait until morning," the system marks the case high risk. It does not reassure the family casually. It escalates oxygen and powered-medical-device interruption, asks for location and callback number, and routes the case through emergency, utility medical-priority, or clinical support channels.

The intended users are community volunteers, shelter coordinators, and small emergency-response teams. The assistant does not replace emergency services. It turns rough notes into safer next actions, clearer questions, and a handoff that a human team can review.

## Technical Design

The core contribution is a lightweight safety sidecar around generation. The sidecar detects high-risk signals such as children exposed to cold, older adults missing medication, pregnancy, insulin continuity, oxygen devices, downed power lines, floodwater, heat illness with medication or mobility risk, dialysis needs, transport barriers, pet-compatible shelter needs, cooling-center routing needs, language-access barriers, and unverified shelter-capacity rumors.

Those signals become constraints for the response:

- Do not diagnose.
- Do not invent shelter capacity, road safety, transport availability, or medical conclusions.
- Escalate immediate danger to official responders.
- Use official local channels before routing people to a location.
- Use qualified interpreters for safety-critical medical, legal, registration, or shelter details.

The playbook grounding layer maps each case to auditable rule IDs, including `PB-LIFE-SAFETY-ESCALATE`, `PB-SHELTER-CAPACITY`, `PB-MEDICATION-CONTINUITY`, `PB-ACCESSIBLE-TRANSPORT`, `PB-PET-SHELTER`, `PB-LANGUAGE-ACCESS`, and `PB-HEAT-COOLING-CENTER`. The responder handoff preserves a short `Playbook basis` line, and the responder packet turns the result into a copy-ready operational summary. The public demo also shows a decision brief with review level, playbook count, official-route count, and audit readiness in the first result viewport.

I also added a household-facing message. This is intentionally separate from the responder packet. It is a plain-English holding note that a volunteer can safely share while waiting for official verification or an interpreter. It asks for callback/location, explains that the case is being routed through official local channels, and avoids pretending to be a full translation or medical/legal instruction.

The submitted EXP-029 version adds an `Audit trace`, explicit `Human review reason`, a `Source verification ledger`, an ICS-style `Transfer brief`, and a structured case export with fields such as `case_fingerprint`, `risk_level`, `review_level`, `signals`, `human_review_reason`, `source_verification`, `transfer_brief`, `playbook_ids`, `official_routes`, `blocked_claims`, `required_human_review`, and `response_contract`. The source ledger quarantines social-media rumors, checks freshness for routes and facility capacity, and tells volunteers to state what is known, unknown, and being checked. The transfer brief follows FEMA ICS 201-style incident briefing ideas: incident snapshot, immediate objectives, safety constraints, resource status, communications, unresolved questions, and operational-period rechecks. This makes the safety sidecar inspectable rather than hidden in prose.

Gemma 4 evidence was captured in a Kaggle Notebook using the official model resource:

`/kaggle/input/models/google/gemma-4/transformers/gemma-4-e2b-it/1`

The notebook logs Python 3.12.12, Torch 2.10.0+cu128, Transformers 5.8.0.dev0, CUDA on Tesla T4, prompt, response, latency, and generated token count. One recorded run produced 160 new tokens with 18.014 seconds latency. The intended production pattern is Gemma 4 for language generation, with the sidecar acting as a pre-generation risk detector and post-generation safety contract.

The current public repository also includes an offline agentic learning sidecar. It does not change the EXP-029 response contract. It reads local validation outcomes and writes an experience ledger, validation feedback memory, a bounded long-term memory store, retrieval index, retrieval demos, memory consolidation report, strategy reflection notes, a human-reviewed skill library, a no-network tool calling sandbox log, and a bounded Voyager-style learning loop summary. The memory system separates episodic, semantic, procedural, and reflective memory so the agent can retrieve similar validation experience and propose next-round strategy updates while keeping every high-risk policy change under human review. It does not call external services or autonomously update response policy.

## Validation

This hackathon has no provided training dataset, so local validation is scenario-based. I split cases into:

- Demo cases: presentation examples.
- Holdout cases: safety checks not baked into prompts.
- Stress cases: edge cases that often break generic assistants.

Current local validation passes:

- Demo: 2/2
- Holdout: 2/2
- Stress: 15/15

The submitted EXP-029 version extends the stress gate to 15/15. The stress set covers pregnancy plus insulin continuity, oxygen power loss, heatwave/cooling-center routing, Spanish/Cantonese/Vietnamese language access, shelter-capacity rumors, official resource routing, accessible transport, pet-compatible shelter, playbook grounding, responder packet false-promise blocking, household messages, audit trace reviewability, machine-readable case export reviewability, human-review rationale for multifactor cases, source verification for out-of-date social-media claims, and ICS-style shift-change transfer briefing.

The tests are small but targeted. They force the project to prove the claims in this writeup: risk detection, official-channel routing, no diagnosis, no invented capacity, playbook traceability, qualified language access, and auditable handoff behavior.

## Why It Matters

Disaster response is full of partial information. A volunteer may know that a child is cold, an older adult missed dialysis, a household has a dog, a road is closed, and a rumor says a shelter has beds. The dangerous failure mode is not silence. It is confident improvisation.

Resilience Copilot is deliberately narrow: one crisis workflow, visible safety constraints, public code, public demo, scenario validation, Gemma 4 runtime evidence, and a path to stronger multilingual generation. The newest source-verification and transfer-brief layers are informed by CDC CERC crisis communication principles, NIST AI RMF risk management, FEMA ICS 201 incident briefing practice, and crisis-informatics work on timely, credible disaster information. The project is meant to make human responders faster and less likely to miss high-risk signals, while keeping final decisions with official local teams.

## Links

Public demo: https://huier5635-cmd.github.io/resilience-copilot-gemma4/

Public code: https://github.com/huier5635-cmd/resilience-copilot-gemma4

Video: https://youtu.be/CmqCV8Ic9cY

Kaggle Gemma 4 evidence notebook: https://www.kaggle.com/code/zhenhuier/notebook5022dfd167

The repository includes the static demo, validation scripts, scenario cases, pitch deck, evidence screenshots, and submission bundle. Latest submitted bundle: `resilience_copilot_submission_bundle_EXP029.zip`.
