# EXP-021 Judging Evidence Matrix

Purpose: make the final Kaggle submission easy to review under deadline pressure. Each claim below points to a concrete asset, link, command, or validation result.

## Judge-Facing Links

| Evidence | Link |
| --- | --- |
| Kaggle writeup | https://www.kaggle.com/competitions/gemma-4-good-hackathon/writeups/new-writeup-1778665719423 |
| Public demo | https://huier5635-cmd.github.io/resilience-copilot-gemma4/ |
| Public code | https://github.com/huier5635-cmd/resilience-copilot-gemma4 |
| Video | https://youtu.be/CmqCV8Ic9cY |
| Kaggle Gemma 4 evidence notebook | https://www.kaggle.com/code/zhenhuier/notebook5022dfd167 |

## Rubric Map

| Rubric area | What the judge should see | Primary evidence | Backup evidence |
| --- | --- | --- | --- |
| Impact and vision | Disaster volunteers need safer triage for evacuation, medication, shelter, pets, language access, and official handoff. | `docs/final_kaggle_writeup_EXP020.md`; video; pitch deck | `README.md`; public demo |
| Technical depth | A sidecar detects risk signals, explains the human review reason, verifies source freshness, adds playbook IDs, creates an ICS-style transfer brief, blocks unsafe claims, routes official resource checks, creates responder/household outputs, and records local validation feedback through an offline agentic learning sidecar with bounded long-term memory. | `scripts/resilience_copilot_baseline.py`; `scripts/agentic_learning_loop.py`; `scripts/agent_memory_system.py`; `public_demo/`; `app/` | `outputs/local_validation/evidence_report.md` |
| Gemma 4 runtime evidence | Official Kaggle model resource is mounted and inference evidence is logged. | `outputs/local_validation/kaggle_gemma4_evidence_20260513.md`; Kaggle notebook link | `notebooks/experiments/kaggle_single_cell_evidence.py` |
| Validation | Scenario validation passes demo, holdout, stress, writeup readiness, and judging packet checks. | `outputs/local_validation/local_validation_report.json`; `outputs/local_validation/evidence_report.md` | `data/cases/*.jsonl` |
| Agentic learning evidence | Offline experience accumulation is implemented from local validation feedback: experience ledger, validation feedback memory, strategy reflection, skill library, no-network tool sandbox, and bounded Voyager-style learning loop summary. | `outputs/local_validation/agentic_learning_report.json`; `knowledge_base/skill_library.json`; `outputs/local_validation/experience_ledger.jsonl` | `outputs/local_validation/strategy_reflection.md`; `outputs/local_validation/voyager_style_learning_loop.json` |
| Memory-system evidence | A bounded memory system stores episodic, semantic, procedural, and reflective memories, then provides deterministic retrieval demos, consolidation, protected safety invariants, and memory-safety policy. | `outputs/local_validation/memory_system_report.json`; `outputs/local_validation/agent_memory_store.json`; `outputs/local_validation/memory_retrieval_demo.json` | `outputs/local_validation/memory_consolidation_report.md`; `outputs/local_validation/memory_safety_policy.json` |
| Original branch | The original improvements are safety sidecar, official routing, language access, playbook grounding, responder packet, household message, audit trace, structured export, human review reason, source verification ledger, and transfer brief. | `scripts/resilience_copilot_baseline.py`; `data/cases/stress_cases.jsonl`; public demo | `outputs/local_validation/stress_eval.json` |
| Storytelling | The project is understandable in a short video and editable pitch deck, not just code. | `outputs/submission_assets/resilience_copilot_pitch_v2.pptx`; YouTube link | public demo |
| Reproducibility | Public repo, static demo package, EXP-029 evidence bundle, and scripts are included. | `resilience_copilot_submission_bundle_EXP029.zip`; GitHub link | `outputs/submission_assets/public_demo_static.zip` |

## Final Submission Status

1. EXP-029 has been submitted to Kaggle.
2. Latest attachment: `resilience_copilot_submission_bundle_EXP029.zip`.
3. Public demo URL, public repo URL, YouTube URL, and Kaggle evidence notebook URL are present in the writeup.
4. Local validation is demo 2/2, holdout 2/2, stress 15/15, and `ready_to_submit=true`.
5. The project should remain locked unless a real link, attachment, or display error is found.

## What Not To Overclaim

- Do not claim live shelter capacity.
- Do not claim medical diagnosis or treatment.
- Do not claim road, transport, or utility availability is current unless verified through official local channels.
- Do not claim the household message is a complete translation for safety-critical details; qualified interpreters are required.
- Do not claim the small validation set proves field deployment readiness. It proves targeted safety gates for the hackathon prototype.

# EXP-029 Final Evidence Note

- Technical depth update: EXP-029 includes `Transfer brief`, `Source verification ledger`, `Human review reason`, responder handoff, responder packet, audit trace, and structured export.
- Agentic sidecar update: the public repository now includes offline experience ledger, validation feedback memory, bounded long-term memory store, retrieval demos, memory consolidation, strategy reflection, skill library, no-network tool sandbox, and bounded Voyager-style learning loop artifacts. These are review-only learning artifacts; they do not claim live external tool use or automatic policy updates.
- Validation update: stress validation is 15/15 locally; EXP-029 adds `stress_ics_transfer_brief_handoff`.
- Literature basis: FEMA ICS 201 incident briefing structure, plus CDC CERC and NIST AI RMF safety framing.
- Submission status: EXP-029 was submitted to Kaggle on 2026-05-17 after public demo and evidence bundle refresh.
